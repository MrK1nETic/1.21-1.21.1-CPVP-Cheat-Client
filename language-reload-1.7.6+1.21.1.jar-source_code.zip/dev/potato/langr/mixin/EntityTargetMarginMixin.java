package dev.potato.langr.mixin;

import dev.potato.langr.Langr;
import dev.potato.langr.event.EventManager;
import dev.potato.langr.event.events.TargetMarginListener;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1297.class})
public class EntityTargetMarginMixin {
   @Inject(
      method = {"getTargetingMargin"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onGetTargetingMargin(CallbackInfoReturnable<Float> cir) {
      class_1297 entity = (class_1297)this;
      TargetMarginListener.TargetMarginEvent event = new TargetMarginListener.TargetMarginEvent(entity, cir);
      Langr.INSTANCE.getEventManager();
      EventManager.fire(event);
      if (!event.isCancelled()) {
         ;
      }
   }
}
