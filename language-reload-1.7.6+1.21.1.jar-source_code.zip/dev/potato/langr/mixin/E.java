package dev.potato.langr.mixin;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_636.class})
public interface E {
   @Invoker("syncSelectedSlot")
   void syncSlot();
}
