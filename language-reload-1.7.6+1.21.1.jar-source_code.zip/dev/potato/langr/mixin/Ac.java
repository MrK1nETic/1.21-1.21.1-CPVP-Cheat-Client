package dev.potato.langr.mixin;

import dev.potato.langr.event.EventManager;
import dev.potato.langr.event.events.Render3DListener;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_757.class})
public class Ac {
   @Shadow
   @Final
   private class_4184 field_18765;

   @Inject(
      method = {"renderWorld"},
      at = {@At("HEAD")}
   )
   private void onRenderWorld(class_9779 tickCounter, CallbackInfo ci) {
      class_4587 matrices = new class_4587();
      double x = this.field_18765.method_19326().field_1352;
      double y = this.field_18765.method_19326().field_1351;
      double z = this.field_18765.method_19326().field_1350;
      EventManager.fire(Render3DListener.Render3DEvent.get(matrices, tickCounter.method_60637(true), x, y, z, 0.05));
   }
}
