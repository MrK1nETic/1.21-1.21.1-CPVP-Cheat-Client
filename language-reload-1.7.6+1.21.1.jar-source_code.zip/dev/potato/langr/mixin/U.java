package dev.potato.langr.mixin;

import net.minecraft.class_243;
import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_745.class})
public interface U {
   @Accessor("velocityLerpDivisor")
   int getModDelAALerpDivisor();

   @Accessor("velocityLerpDivisor")
   void setModDelAALerpDivisor(int var1);

   @Accessor("clientModDelAA")
   class_243 getClientModDelAA();

   @Accessor("clientModDelAA")
   void setClientModDelAA(class_243 var1);
}
