package dev.potato.langr.mixin;

import dev.potato.langr.Langr;
import dev.potato.langr.event.EventManager;
import dev.potato.langr.event.events.AttackListener;
import dev.potato.langr.event.events.BlockBreakingListener;
import dev.potato.langr.event.events.ItemUseListener;
import dev.potato.langr.event.events.ResolutionListener;
import dev.potato.langr.event.events.TickListener;
import dev.potato.langr.utils.MouseSimulation;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_310.class})
public class S {
   @Shadow
   public @Nullable class_638 field_1687;
   @Shadow
   @Final
   private class_1041 field_1704;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo ci) {
      if (this.field_1687 != null) {
         TickListener.TickEvent event = new TickListener.TickEvent();
         EventManager.fire(event);
      }

   }

   @Inject(
      method = {"onResolutionChanged"},
      at = {@At("HEAD")}
   )
   private void onResolutionChanged(CallbackInfo ci) {
      EventManager.fire(new ResolutionListener.ResolutionEvent(this.field_1704));
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onItemUse(CallbackInfo ci) {
      ItemUseListener.ItemUseEvent event = new ItemUseListener.ItemUseEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

      if (MouseSimulation.isMouseButtonPressed(1)) {
         MouseSimulation.mouseButtons.put(1, false);
         ci.cancel();
      }

   }

   @Inject(
      method = {"doAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAttack(CallbackInfoReturnable<Boolean> cir) {
      AttackListener.AttackEvent event = new AttackListener.AttackEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         cir.setReturnValue(false);
      }

      if (MouseSimulation.isMouseButtonPressed(0)) {
         MouseSimulation.mouseButtons.put(0, false);
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onBlockBreaking(boolean breaking, CallbackInfo ci) {
      BlockBreakingListener.BlockBreakingEvent event = new BlockBreakingListener.BlockBreakingEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

      if (MouseSimulation.isMouseButtonPressed(0)) {
         MouseSimulation.mouseButtons.put(0, false);
         ci.cancel();
      }

   }

   @Inject(
      method = {"stop"},
      at = {@At("HEAD")}
   )
   private void onClose(CallbackInfo ci) {
      Langr.INSTANCE.getProfileManager().saveProfile();
   }
}
