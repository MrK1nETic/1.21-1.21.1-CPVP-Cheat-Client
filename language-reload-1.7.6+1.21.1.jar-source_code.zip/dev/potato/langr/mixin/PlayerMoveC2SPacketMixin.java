package dev.potato.langr.mixin;

import dev.potato.langr.imixin.IServerboundMovePlayerPacket;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2828.class})
public abstract class PlayerMoveC2SPacketMixin implements IServerboundMovePlayerPacket {
   @Unique
   private boolean langr$hasRot = false;

   @Accessor("yaw")
   public abstract void setYaw(float var1);

   @Accessor("pitch")
   public abstract void setPitch(float var1);

   @Accessor("changeLook")
   public abstract void setChangeLook(boolean var1);

   public void setYRot(float yRot) {
      this.setYaw(yRot);
      this.setChangeLook(true);
      this.langr$hasRot = true;
   }

   public void setXRot(float xRot) {
      this.setPitch(xRot);
      this.setChangeLook(true);
      this.langr$hasRot = true;
   }

   public void setHasRot(boolean hasRot) {
      this.langr$hasRot = hasRot;
   }
}
