package dev.potato.langr.imixin;

public interface IKeyBinding {
   boolean isActuallyPressed();

   void resetPressed();
}
