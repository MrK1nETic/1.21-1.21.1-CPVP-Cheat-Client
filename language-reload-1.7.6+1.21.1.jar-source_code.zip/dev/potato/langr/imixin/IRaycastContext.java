package dev.potato.langr.imixin;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3959;

public interface IRaycastContext {
   void set(class_243 var1, class_243 var2, class_3959.class_3960 var3, class_3959.class_242 var4, class_1297 var5);
}
