package dev.potato.langr.imixin;

import net.minecraft.class_243;

public interface IExplosion {
   void set(class_243 var1, float var2, boolean var3);
}
