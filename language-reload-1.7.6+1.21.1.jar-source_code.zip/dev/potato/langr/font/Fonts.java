package dev.potato.langr.font;

public final class Fonts {
   public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/languagereloadx/font/font.ttf", 40, false, false, false);
}
