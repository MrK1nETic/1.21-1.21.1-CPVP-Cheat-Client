package dev.potato.langr.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.potato.langr.Langr;
import dev.potato.langr.mixin.Y;
import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class RenderManager {
   public static final class_289 TESSELLATOR = RenderSystem.renderThreadTesselator();

   public static void post(Runnable callback) {
      callback.run();
   }

   public static void renderBox(class_4587 matrices, class_2338 p, int color) {
      renderBox(matrices, new class_238(p), color);
   }

   public static void renderBox(class_4587 matrices, class_238 box, int color) {
      if (isFrustumVisible(box)) {
         matrices.method_22903();
         drawBox(matrices, box, color);
         matrices.method_22909();
      }
   }

   public static void drawBox(class_4587 matrices, class_238 box, int color) {
      drawBox(matrices, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, color);
   }

   public static void drawBox(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderSide(class_4587 matrices, float x1, float y1, float z1, float x2, float y2, float z2, class_2350 direction, int color) {
      matrices.method_22903();
      drawSide(matrices, (double)x1, (double)y1, (double)z1, (double)x2, (double)y2, (double)z2, direction, color);
      matrices.method_22909();
   }

   public static void renderSide(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, class_2350 direction, int color) {
      matrices.method_22903();
      drawSide(matrices, x1, y1, z1, x2, y2, z2, direction, color);
      matrices.method_22909();
   }

   public static void drawSide(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, class_2350 direction, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_27382, class_290.field_1576);
      if (direction.method_10166().method_10178()) {
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
      } else if (direction != class_2350.field_11043 && direction != class_2350.field_11035) {
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
      } else {
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderPlane(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      matrices.method_22903();
      drawPlane(matrices, x1, y1, z1, x2, y2, z2, color);
      matrices.method_22909();
   }

   public static void drawPlane(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderBoundingCross(class_4587 matrices, class_2338 p, float width, int color) {
      renderBoundingCross(matrices, new class_238(p), width, color);
   }

   public static void renderBoundingCross(class_4587 matrices, class_238 box, float width, int color) {
      if (isFrustumVisible(box)) {
         matrices.method_22903();
         RenderSystem.lineWidth(width);
         drawBoundingCross(matrices, box, color);
         matrices.method_22909();
      }
   }

   public static void drawBoundingCross(class_4587 matrices, class_238 box, int color) {
      drawBoundingCross(matrices, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, color);
   }

   public static void drawBoundingCross(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_29344, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderBoundingBox(class_4587 matrices, class_2338 p, float width, int color) {
      renderBoundingBox(matrices, new class_238(p), width, color);
   }

   public static void renderBoundingBox(class_4587 matrices, class_238 box, float width, int color) {
      if (isFrustumVisible(box)) {
         matrices.method_22903();
         RenderSystem.lineWidth(width);
         drawBoundingBox(matrices, box, 1.0F, color);
         matrices.method_22909();
      }
   }

   public static void drawBoundingBox(class_4587 matrices, class_238 box, float v, int color) {
      drawBoundingBox(matrices, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, color);
   }

   public static void drawBoundingBox(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_29344, class_290.field_1576);
      double dx = x2 - x1;
      double dy = y2 - y1;
      double dz = z2 - z1;
      if (dy == (double)0.0F) {
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z2).method_22915(g, h, i, f);
         bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z1).method_22915(g, h, i, f);
      } else {
         class_259.method_1081((double)0.0F, (double)0.0F, (double)0.0F, dx, dy, dz).method_1104((minX, minY, minZ, maxX, maxY, maxZ) -> {
            bufferBuilder.method_22918(matrix4f, (float)(minX + x1), (float)(minY + y1), (float)(minZ + z1)).method_22915(g, h, i, f);
            bufferBuilder.method_22918(matrix4f, (float)(maxX + x1), (float)(maxY + y1), (float)(maxZ + z1)).method_22915(g, h, i, f);
         });
      }

      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderLine(class_4587 matrices, class_243 s, class_243 d, float width, int color) {
      renderLine(matrices, s.field_1352, s.field_1351, s.field_1350, d.field_1352, d.field_1351, d.field_1350, width, color);
   }

   public static void renderLine(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, float width, int color) {
      matrices.method_22903();
      RenderSystem.lineWidth(width);
      drawLine(matrices, x1, y1, z1, x2, y2, z2, color);
      matrices.method_22909();
   }

   public static void drawLine(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, int color) {
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float i = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_29344, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z1).method_22915(g, h, i, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z2).method_22915(g, h, i, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderSign(String text, class_243 pos, int color) {
      renderSign(text, pos.method_10216(), pos.method_10214(), pos.method_10215(), color);
   }

   public static void renderSign(String text, class_243 pos, float scaling, int color) {
      renderSign(text, pos.method_10216(), pos.method_10214(), pos.method_10215(), scaling, color);
   }

   public static void renderSign(String text, double x, double y, double z, int color) {
      class_4184 camera = Langr.mc.field_1773.method_19418();
      class_243 pos = camera.method_19326();
      double dist = Math.sqrt(pos.method_1028(x, y, z));
      float scaling = (float)((double)0.0018F + 0.0025 * dist);
      if (dist <= (double)8.0F) {
         scaling = 0.0245F;
      }

      renderSign(text, x, y, z, scaling, color);
   }

   public static void renderSign(String text, double x, double y, double z, float scaling, int color) {
      class_4184 camera = Langr.mc.field_1773.method_19418();
      class_243 pos = camera.method_19326();
      class_4587 matrices = new class_4587();
      matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
      matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
      matrices.method_22904(x - pos.method_10216(), y - pos.method_10214(), z - pos.method_10215());
      matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
      matrices.method_22905(-scaling, -scaling, -1.0F);
      float hwidth = (float)Langr.mc.field_1772.method_1727(text) / 2.0F;
      float textWidth = (float)Langr.mc.field_1772.method_1727(text);
      Objects.requireNonNull(Langr.mc.field_1772);
      float textHeight = 9.0F;
      float padding = 2.0F;
      post(() -> {
         GL11.glDepthFunc(519);
         class_4597.class_4598 vertexConsumers = Langr.mc.method_22940().method_23000();
         rect(matrices, (double)(-hwidth - padding), (double)(-padding), (double)(textWidth + 2.0F * padding), (double)(textHeight + 2.0F * padding), (double)0.0F, 2130706432);
         Langr.mc.field_1772.method_27521(text, -hwidth, 0.0F, color, true, matrices.method_23760().method_23761(), vertexConsumers, class_6415.field_33994, 0, 15728880);
         vertexConsumers.method_22993();
         Langr.mc.field_1772.method_27521(text, -hwidth, 0.0F, color, false, matrices.method_23760().method_23761(), vertexConsumers, class_6415.field_33994, 0, 15728880);
         vertexConsumers.method_22993();
         GL11.glDepthFunc(515);
      });
   }

   public static boolean isFrustumVisible(class_238 box) {
      return ((Y)Langr.mc.field_1769).getFrustum().method_23093(box);
   }

   public static void rect(class_4587 matrices, double x1, double y1, double x2, double y2, int color) {
      rect(matrices, x1, y1, x2, y2, (double)0.0F, color);
   }

   public static void borderedRect(class_4587 matrices, double x1, double y1, double x2, double y2, int borderColor, double thickness) {
      rect(matrices, x1 - thickness, y1 - thickness, thickness, y2 + thickness * (double)2.0F, borderColor);
      rect(matrices, x1 + x2, y1 - thickness, thickness, y2 + thickness * (double)2.0F, borderColor);
      rect(matrices, (double)((float)x1), (double)((float)(y1 - thickness - (double)1.0F)), (double)((float)x2), (double)((float)thickness), borderColor);
      rect(matrices, (double)((float)x1), (double)((float)(y1 + y2 + (double)1.0F)), (double)((float)x2), (double)((float)thickness), borderColor);
   }

   public static void borderedRectLine(class_4587 matrices, double x1, double y1, double x2, double y2, int borderColor) {
      rectLine(matrices, x1, y1, (double)0.0F, y2, borderColor);
      rectLine(matrices, x1 + x2, y1, (double)0.0F, y2, borderColor);
      rectLine(matrices, x1, y1, x2, (double)0.0F, borderColor);
      rectLine(matrices, x1, y1 + y2, x2, (double)0.0F, borderColor);
   }

   public static void rect(class_4587 matrices, double x1, double y1, double x2, double y2, double z, int color) {
      x2 += x1;
      y2 += y1;
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      if (x1 < x2) {
         double i = x1;
         x1 = x2;
         x2 = i;
      }

      if (y1 < y2) {
         double i = y1;
         y1 = y2;
         y2 = i;
      }

      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float j = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, (float)z).method_22915(g, h, j, f);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y2, (float)z).method_22915(g, h, j, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, (float)z).method_22915(g, h, j, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y1, (float)z).method_22915(g, h, j, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void rectLine(class_4587 matrices, double x1, double y1, double x2, double y2, int color) {
      x2 += x1;
      y2 += y1;
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      if (x1 < x2) {
         double i = x1;
         x1 = x2;
         x2 = i;
      }

      if (y1 < y2) {
         double i = y1;
         y1 = y2;
         y2 = i;
      }

      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float j = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = TESSELLATOR.method_60827(class_5596.field_29344, class_290.field_1576);
      bufferBuilder.method_22918(matrix4f, (float)x1, (float)y1, 0.0F).method_22915(g, h, j, f);
      bufferBuilder.method_22918(matrix4f, (float)x2, (float)y2, 0.0F).method_22915(g, h, j, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void rectGradient(class_4587 matrices, double x1, double y1, double x2, double y2, int color, int color1) {
      x2 += x1;
      y2 += y1;
      if (x1 < x2) {
         double i = x1;
         x1 = x2;
         x2 = i;
      }

      if (y1 < y2) {
         double i = y1;
         y1 = y2;
         y2 = i;
      }

      fillGradientQuad(matrices, (float)x1, (float)y1, (float)x2, (float)y2, color1, color, true);
   }

   public static void fillGradientQuad(class_332 context, float x1, float y1, float x2, float y2, int startColor, int endColor, boolean sideways) {
      fillGradientQuad(context.method_51448(), x1, y1, x2, y2, startColor, endColor, sideways);
   }

   public static void fillGradientQuad(class_4587 matrixStack, float x1, float y1, float x2, float y2, int startColor, int endColor, boolean sideways) {
      float f = (float)(startColor >> 24 & 255) / 255.0F;
      float f1 = (float)(startColor >> 16 & 255) / 255.0F;
      float f2 = (float)(startColor >> 8 & 255) / 255.0F;
      float f3 = (float)(startColor & 255) / 255.0F;
      float f4 = (float)(endColor >> 24 & 255) / 255.0F;
      float f5 = (float)(endColor >> 16 & 255) / 255.0F;
      float f6 = (float)(endColor >> 8 & 255) / 255.0F;
      float f7 = (float)(endColor & 255) / 255.0F;
      Matrix4f posMatrix = matrixStack.method_23760().method_23761();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1576);
      if (sideways) {
         bufferBuilder.method_22918(posMatrix, x1, y1, 0.0F).method_22915(f1, f2, f3, f);
         bufferBuilder.method_22918(posMatrix, x1, y2, 0.0F).method_22915(f1, f2, f3, f);
         bufferBuilder.method_22918(posMatrix, x2, y2, 0.0F).method_22915(f5, f6, f7, f4);
         bufferBuilder.method_22918(posMatrix, x2, y1, 0.0F).method_22915(f5, f6, f7, f4);
      } else {
         bufferBuilder.method_22918(posMatrix, x2, y1, 0.0F).method_22915(f1, f2, f3, f);
         bufferBuilder.method_22918(posMatrix, x1, y1, 0.0F).method_22915(f1, f2, f3, f);
         bufferBuilder.method_22918(posMatrix, x1, y2, 0.0F).method_22915(f5, f6, f7, f4);
         bufferBuilder.method_22918(posMatrix, x2, y2, 0.0F).method_22915(f5, f6, f7, f4);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void rectTextured(class_4587 matrix, class_2960 identifier, float x0, float x1, float y0, float y1, float z, float u0, float u1, float v0, float v1, float red, float green, float blue, float alpha) {
      Matrix4f matrix4f = matrix.method_23760().method_23761();
      RenderSystem.setShaderTexture(0, identifier);
      RenderSystem.setShader(class_757::method_34543);
      RenderSystem.enableBlend();
      class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
      buffer.method_22918(matrix4f, x0, y0, z).method_22915(red, green, blue, alpha).method_22913(u0, v0);
      buffer.method_22918(matrix4f, x0, y1, z).method_22915(red, green, blue, alpha).method_22913(u0, v1);
      buffer.method_22918(matrix4f, x1, y1, z).method_22915(red, green, blue, alpha).method_22913(u1, v1);
      buffer.method_22918(matrix4f, x1, y0, z).method_22915(red, green, blue, alpha).method_22913(u1, v0);
      class_286.method_43433(buffer.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderText(class_332 context, String text, float x, float y, int color) {
      context.method_51433(Langr.mc.field_1772, text, (int)x, (int)y, color, true);
   }

   public static int textWidth(String text) {
      return Langr.mc.field_1772.method_1727(text);
   }

   public static int textHeight() {
      Objects.requireNonNull(Langr.mc.field_1772);
      return 9;
   }
}
