package dev.potato.langr.utils;

public final class Animation {
   private double value;
   private final double end;

   public Animation(double end) {
      this.value = end;
      this.end = end;
   }

   public void animate(double speed, double target) {
      this.value = MathUtils.goodLerp((float)speed, this.value, target);
   }

   public double getAnimation() {
      return this.value;
   }

   public void setAnimation(double factor) {
      this.value = MathUtils.smoothStepLerp(factor, this.value, this.end);
   }
}
