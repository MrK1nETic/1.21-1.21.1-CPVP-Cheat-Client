package dev.potato.langr.utils.rotation;

public record Rotation(double yaw, double pitch) {
}
