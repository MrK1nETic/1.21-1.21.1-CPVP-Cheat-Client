package dev.potato.langr.utils.rotation;

import dev.potato.langr.Langr;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class RotationUtils {
   public static Rotation getDirection(class_1297 entity, class_243 vec) {
      double dx = vec.field_1352 - entity.method_23317();
      double dy = vec.field_1351 - entity.method_23318();
      double dz = vec.field_1350 - entity.method_23321();
      double dist = (double)class_3532.method_15355((float)(dx * dx + dz * dz));
      return new Rotation(class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F), -class_3532.method_15338(Math.toDegrees(Math.atan2(dy, dist))));
   }

   public static double getAngleToRotation(Rotation rotation) {
      double currentYaw = (double)class_3532.method_15393(Langr.mc.field_1724.method_36454());
      double currentPitch = (double)class_3532.method_15393(Langr.mc.field_1724.method_36455());
      double diffYaw = class_3532.method_15338(currentYaw - rotation.yaw());
      double diffPitch = class_3532.method_15338(currentPitch - rotation.pitch());
      return Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
   }

   public static class_243 getPlayerLookVec(float yaw, float pitch) {
      float f = pitch * ((float)Math.PI / 180F);
      float g = -yaw * ((float)Math.PI / 180F);
      float h = class_3532.method_15362(g);
      float i = class_3532.method_15374(g);
      float j = class_3532.method_15362(f);
      float k = class_3532.method_15374(f);
      return new class_243((double)(i * j), (double)(-k), (double)(h * j));
   }

   public static class_243 getPlayerLookVec(class_1657 player) {
      return getPlayerLookVec(player.method_36454(), player.method_36455());
   }

   public static class_239 getHitResult(class_1657 entity, boolean ignoreInvisibles, float yaw, float pitch) {
      class_239 result = null;
      if (entity != null && Langr.mc.field_1687 != null) {
         double d = (double)4.5F;
         class_243 cameraPosVec = entity.method_5836((float)Langr.mc.method_47600());
         class_243 rotationVec = getPlayerLookVec(yaw, pitch);
         class_243 range = cameraPosVec.method_1031(rotationVec.field_1352 * d, rotationVec.field_1351 * d, rotationVec.field_1350 * d);
         result = Langr.mc.field_1687.method_17742(new class_3959(cameraPosVec, range, class_3960.field_17559, class_242.field_1348, entity));
         boolean bl = false;
         if (d > (double)3.0F) {
            bl = true;
         }

         double e = d * d;
         if (result != null) {
            e = result.method_17784().method_1025(cameraPosVec);
         }

         class_243 vec3d3 = cameraPosVec.method_1031(rotationVec.field_1352 * d, rotationVec.field_1351 * d, rotationVec.field_1350 * d);
         float f = 1.0F;
         class_238 box = entity.method_5829().method_18804(rotationVec.method_1021(d)).method_1009((double)1.0F, (double)1.0F, (double)1.0F);
         class_3966 entityHitResult = class_1675.method_18075(entity, cameraPosVec, vec3d3, box, (entityx) -> !entityx.method_7325() && entityx.method_5863() && entityx.method_5767() && !ignoreInvisibles, e);
         if (entityHitResult != null) {
            class_243 vec3d4 = entityHitResult.method_17784();
            double g = cameraPosVec.method_1025(vec3d4);
            if (bl && g > (double)9.0F) {
               result = class_3965.method_17778(vec3d4, class_2350.method_10142(rotationVec.field_1352, rotationVec.field_1351, rotationVec.field_1350), class_2338.method_49638(vec3d4));
            } else if (g < e || result == null) {
               result = entityHitResult;
            }
         }
      }

      return result;
   }

   public static class_239 getHitResult(class_1657 player, boolean ignoreInvisibles) {
      return getHitResult(player, ignoreInvisibles, player.method_36454(), player.method_36455());
   }

   public static Rotation getSmoothRotation(Rotation from, Rotation to, double speed) {
      return new Rotation((double)class_3532.method_17821((float)speed, (float)from.yaw(), (float)to.yaw()), (double)class_3532.method_17821((float)speed, (float)from.pitch(), (float)to.pitch()));
   }

   public static Rotation getDiff(Rotation rotation1, Rotation rotation2) {
      double yaw = Math.abs(Math.max(rotation1.yaw(), rotation2.yaw()) - Math.min(rotation1.yaw(), rotation2.yaw()));
      double pitch = Math.abs(Math.max(rotation1.pitch(), rotation2.pitch()) - Math.min(rotation1.pitch(), rotation2.pitch()));
      return new Rotation(yaw, pitch);
   }

   public static double getTotalDiff(Rotation rotation1, Rotation rotation2) {
      Rotation diff = getDiff(rotation1, rotation2);
      return diff.yaw() + diff.pitch();
   }

   public static class Rotation {
      private double yaw;
      private double pitch;
      private Runnable callback;

      public Rotation(double yaw, double pitch) {
         this.yaw = yaw;
         this.pitch = pitch;
      }

      public Rotation(double yaw, double pitch, Runnable callback) {
         this.yaw = yaw;
         this.pitch = pitch;
         this.callback = callback;
      }

      public double yaw() {
         return this.yaw;
      }

      public double pitch() {
         return this.pitch;
      }

      public void sendPacket() {
         Langr.mc.method_1562().method_52787(new class_2828.class_2831((float)this.yaw(), (float)this.pitch, Langr.mc.field_1724.method_24828()));
      }

      public void runCallback() {
         if (this.callback != null) {
            this.callback.run();
         }

      }
   }
}
