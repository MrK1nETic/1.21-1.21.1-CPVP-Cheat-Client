package dev.potato.langr.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.potato.langr.Langr;
import dev.potato.langr.module.modules.client.ClickMen;
import java.awt.Color;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_8251;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public final class RenderUtils {
   public static class_8251 vertexSorter;
   public static boolean rendering3D = true;

   public static class_243 getCameraPos() {
      return Langr.mc.method_31975().field_4344.method_19326();
   }

   public static class_4184 getCamera() {
      return Langr.mc.method_31975().field_4344;
   }

   public static double deltaTime() {
      return Langr.mc.method_47599() > 0 ? (double)1.0F / (double)Langr.mc.method_47599() : (double)1.0F;
   }

   public static float fast(float end, float start, float multiple) {
      return (1.0F - class_3532.method_15363((float)(deltaTime() * (double)multiple), 0.0F, 1.0F)) * end + class_3532.method_15363((float)(deltaTime() * (double)multiple), 0.0F, 1.0F) * start;
   }

   public static class_243 getPlayerLookVec(class_1657 player) {
      float f = ((float)Math.PI / 180F);
      float pi = (float)Math.PI;
      float f1 = class_3532.method_15362(-player.method_36454() * f - pi);
      float f2 = class_3532.method_15374(-player.method_36454() * f - pi);
      float f3 = -class_3532.method_15362(-player.method_36455() * f);
      float f4 = class_3532.method_15374(-player.method_36455() * f);
      return (new class_243((double)(f2 * f3), (double)f4, (double)(f1 * f3))).method_1029();
   }

   public static void unscaledProjection() {
      vertexSorter = RenderSystem.getVertexSorting();
      RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)Langr.mc.method_22683().method_4489(), (float)Langr.mc.method_22683().method_4506(), 0.0F, 1000.0F, 21000.0F), class_8251.field_43361);
      rendering3D = false;
   }

   public static void scaledProjection() {
      RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)((double)Langr.mc.method_22683().method_4489() / Langr.mc.method_22683().method_4495()), (float)((double)Langr.mc.method_22683().method_4506() / Langr.mc.method_22683().method_4495()), 0.0F, 1000.0F, 21000.0F), vertexSorter);
      rendering3D = true;
   }

   public static void renderRoundedQuad(class_4587 matrices, Color c, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double samples) {
      int color = c.getRGB();
      Matrix4f matrix = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float k = (float)(color & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShader(class_757::method_34540);
      renderRoundedQuadInternal(matrix, g, h, k, f, x, y, x2, y2, corner1, corner2, corner3, corner4, samples);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   private static void setup() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
   }

   private static void cleanup() {
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   public static void renderRoundedQuad(class_4587 matrices, Color c, double x, double y, double x1, double y1, double rad, double samples) {
      renderRoundedQuad(matrices, c, x, y, x1, y1, rad, rad, rad, rad, samples);
   }

   public static void renderRoundedOutlineInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, double fromX, double fromY, double toX, double toY, double radC1, double radC2, double radC3, double radC4, double width, double samples) {
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
      double[][] map = new double[][]{{toX - radC4, toY - radC4, radC4}, {toX - radC2, fromY + radC2, radC2}, {fromX + radC1, fromY + radC1, radC1}, {fromX + radC3, toY - radC3, radC3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin1 = (float)(Math.sin((double)rad1) * rad);
            float sin = (float)((double)sin1 * rad);
            float cos1 = (float)(Math.cos((double)rad1) * rad);
            float cos = (float)((double)cos1 * rad);
            bufferBuilder.method_22918(matrix, (float)current[0] + sin, (float)current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
            bufferBuilder.method_22918(matrix, (float)(current[0] + (double)sin + (double)sin1 * width), (float)(current[1] + (double)cos + (double)cos1 * width), 0.0F).method_22915(cr, cg, cb, ca);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin1 = (float)(Math.sin((double)rad1) * rad);
         float sin = (float)((double)sin1 * rad);
         float cos1 = (float)(Math.cos((double)rad1) * rad);
         float cos = (float)((double)cos1 * rad);
         bufferBuilder.method_22918(matrix, (float)current[0] + sin, (float)current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
         bufferBuilder.method_22918(matrix, (float)(current[0] + (double)sin + (double)sin1 * width), (float)(current[1] + (double)cos + (double)cos1 * width), 0.0F).method_22915(cr, cg, cb, ca);
      }

      int i = 0;
      double[] current = map[i];
      double rad = current[2];
      float cos = (float)rad;
      bufferBuilder.method_22918(matrix, (float)current[0], (float)current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
      bufferBuilder.method_22918(matrix, (float)current[0], (float)(current[1] + (double)cos + width), 0.0F).method_22915(cr, cg, cb, ca);
      class_286.method_43433(bufferBuilder.method_60800());
   }

   public static void setScissorRegion(int x, int y, int width, int height) {
      class_437 currentScreen = class_310.method_1551().field_1755;
      int screenHeight;
      if (currentScreen == null) {
         screenHeight = 0;
      } else {
         screenHeight = currentScreen.field_22790 - height;
      }

      double scaleFactor = class_310.method_1551().method_22683().method_4495();
      GL11.glScissor((int)((double)x * scaleFactor), (int)((double)screenHeight * scaleFactor), (int)((double)(width - x) * scaleFactor), (int)((double)(height - y) * scaleFactor));
      GL11.glEnable(3089);
   }

   public static void renderCircle(class_4587 matrices, Color c, double originX, double originY, double rad, int segments) {
      int segments1 = class_3532.method_15340(segments, 4, 360);
      int color = c.getRGB();
      Matrix4f matrix = matrices.method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float k = (float)(color & 255) / 255.0F;
      setup();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);

      for(int i = 0; i < 360; i += Math.min(360 / segments1, 360 - i)) {
         double radians = Math.toRadians((double)i);
         double sin = Math.sin(radians) * rad;
         double cos = Math.cos(radians) * rad;
         bufferBuilder.method_22918(matrix, (float)(originX + sin), (float)(originY + cos), 0.0F).method_22915(g, h, k, f);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      cleanup();
   }

   public static void renderShaderRect(class_4587 matrixStack, Color color, Color color2, Color color3, Color color4, float f, float f2, float f3, float f4, float f5, float f6) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_289 tessellator = class_289.method_1348();
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27382, class_290.field_1592);
      bufferBuilder.method_22918(matrixStack.method_23760().method_23761(), f - 10.0F, f2 - 10.0F, 0.0F);
      bufferBuilder.method_22918(matrixStack.method_23760().method_23761(), f - 10.0F, f2 + f4 + 20.0F, 0.0F);
      bufferBuilder.method_22918(matrixStack.method_23760().method_23761(), f + f3 + 20.0F, f2 + f4 + 20.0F, 0.0F);
      bufferBuilder.method_22918(matrixStack.method_23760().method_23761(), f + f3 + 20.0F, f2 - 10.0F, 0.0F);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static void renderRoundedOutline(class_332 poses, Color c, double fromX, double fromY, double toX, double toY, double rad1, double rad2, double rad3, double rad4, double width, double samples) {
      int color = c.getRGB();
      Matrix4f matrix = poses.method_51448().method_23760().method_23761();
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float k = (float)(color & 255) / 255.0F;
      setup();
      RenderSystem.setShader(class_757::method_34540);
      renderRoundedOutlineInternal(matrix, g, h, k, f, fromX, fromY, toX, toY, rad1, rad2, rad3, rad4, width, samples);
      cleanup();
   }

   public static class_4587 matrixFrom(double x, double y, double z) {
      class_4587 matrices = new class_4587();
      class_4184 camera = class_310.method_1551().field_1773.method_19418();
      matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
      matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
      matrices.method_22904(x - camera.method_19326().field_1352, y - camera.method_19326().field_1351, z - camera.method_19326().field_1350);
      return matrices;
   }

   public static void renderQuad(class_4587 matrices, float x, float y, float width, float height, int color) {
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      matrices.method_22903();
      matrices.method_22905(0.5F, 0.5F, 0.5F);
      matrices.method_22904((double)x, (double)y, (double)0.0F);
      class_289 tessellator = class_289.method_1348();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22912(0.0F, 0.0F, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22912(0.0F, height, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22912(width, height, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22912(width, 0.0F, 0.0F).method_22915(red, green, blue, alpha);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
      matrices.method_22909();
   }

   public static void renderRoundedQuadInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, double fromX, double fromY, double toX, double toY, double corner1, double corner2, double corner3, double corner4, double samples) {
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      double[][] map = new double[][]{{toX - corner4, toY - corner4, corner4}, {toX - corner2, fromY + corner2, corner2}, {fromX + corner1, fromY + corner1, corner1}, {fromX + corner3, toY - corner3, corner3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin = (float)(Math.sin((double)rad1) * rad);
            float cos = (float)(Math.cos((double)rad1) * rad);
            bufferBuilder.method_22918(matrix, (float)current[0] + sin, (float)current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin = (float)(Math.sin((double)rad1) * rad);
         float cos = (float)(Math.cos((double)rad1) * rad);
         bufferBuilder.method_22918(matrix, (float)current[0] + sin, (float)current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
      }

      class_286.method_43433(bufferBuilder.method_60800());
   }

   public static void renderFilledBox(class_4587 matrices, float f, float f2, float f3, float f4, float f5, float f6, Color color) {
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.setShaderColor((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      RenderSystem.setShader(class_757::method_34539);
      class_289 tessellator = class_289.method_1348();
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27380, class_290.field_1592);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f2, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f3);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f6);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), f4, f5, f6);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

   public static void renderLine(class_4587 matrices, Color color, class_243 start, class_243 end) {
      matrices.method_22903();
      Matrix4f s = matrices.method_23760().method_23761();
      if (ClickMen.antiAliasing.getValue()) {
         GL11.glEnable(32925);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
      }

      GL11.glDepthFunc(519);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableBlend();
      genericAABBRender(class_5596.field_29344, class_290.field_1576, class_757::method_34540, s, start, end.method_1020(start), color, (buffer, x, y, z, x1, y1, z1, red, green, blue, alpha, matrix) -> {
         buffer.method_22918(matrix, x, y, z).method_22915(red, green, blue, alpha);
         buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha);
      });
      GL11.glDepthFunc(515);
      RenderSystem.disableBlend();
      if (ClickMen.antiAliasing.getValue()) {
         GL11.glDisable(2848);
         GL11.glDisable(32925);
      }

      matrices.method_22909();
   }

   private static void genericAABBRender(class_293.class_5596 mode, class_293 format, Supplier<class_5944> shader, Matrix4f stack, class_243 start, class_243 dimensions, Color color, RenderAction action) {
      float red = (float)color.getRed() / 255.0F;
      float green = (float)color.getGreen() / 255.0F;
      float blue = (float)color.getBlue() / 255.0F;
      float alpha = (float)color.getAlpha() / 255.0F;
      class_243 end = start.method_1019(dimensions);
      float x1 = (float)start.field_1352;
      float y1 = (float)start.field_1351;
      float z1 = (float)start.field_1350;
      float x2 = (float)end.field_1352;
      float y2 = (float)end.field_1351;
      float z2 = (float)end.field_1350;
      useBuffer(mode, format, shader, (bufferBuilder) -> action.run(bufferBuilder, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, stack));
   }

   private static void useBuffer(class_293.class_5596 mode, class_293 format, Supplier<class_5944> shader, Consumer<class_287> runner) {
      class_289 t = class_289.method_1348();
      class_287 bb = t.method_60827(mode, format);
      runner.accept(bb);
      setup();
      RenderSystem.setShader(shader);
      class_286.method_43433(bb.method_60800());
      cleanup();
   }

   public static void renderBox(class_4587 matrices, float x1, float y1, float z1, float x2, float y2, float z2, Color color) {
      float red = (float)color.getRed() / 255.0F;
      float green = (float)color.getGreen() / 255.0F;
      float blue = (float)color.getBlue() / 255.0F;
      float alpha = (float)color.getAlpha() / 255.0F;
      Matrix4f matrix = matrices.method_23760().method_23761();
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27377, class_290.field_1576);
      bufferBuilder.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha);
      class_286.method_43433(bufferBuilder.method_60800());
   }

   public static void renderText(class_4587 matrices, String text, float x, float y, float z, Color color) {
      matrices.method_22903();
      class_4184 camera = getCamera();
      if (camera == null) {
         matrices.method_22909();
      } else {
         class_243 cameraPos = camera.method_19326();
         double dx = (double)x - cameraPos.field_1352;
         double dy = (double)y - cameraPos.field_1351;
         double dz = (double)z - cameraPos.field_1350;
         double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
         float scale = (float)(0.025 * distance);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         matrices.method_22905(-scale, -scale, scale);
         matrices.method_22904((double)0.0F, (double)0.0F, -distance);
         float textWidth = (float)Langr.mc.field_1772.method_1727(text) / 2.0F;
         matrices.method_46416(-textWidth, -4.0F, 0.0F);
         Matrix4f matrix = matrices.method_23760().method_23761();
         Langr.mc.field_1772.method_30882(class_2561.method_43470(text), 0.0F, 0.0F, color.getRGB(), false, matrix, Langr.mc.method_22940().method_23000(), class_6415.field_33994, 0, 15728880);
         matrices.method_22909();
      }
   }

   public static void renderOutline(class_4587 matrices, int x1, int y1, int x2, int y2, int color) {
      float f = (float)(color >> 24 & 255) / 255.0F;
      float g = (float)(color >> 16 & 255) / 255.0F;
      float h = (float)(color >> 8 & 255) / 255.0F;
      float k = (float)(color & 255) / 255.0F;
      class_289 tessellator = class_289.method_1348();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), (float)x1, (float)y2, 0.0F).method_22915(g, h, k, f);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), (float)x2, (float)y2, 0.0F).method_22915(g, h, k, f);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), (float)x2, (float)y1, 0.0F).method_22915(g, h, k, f);
      bufferBuilder.method_22918(matrices.method_23760().method_23761(), (float)x1, (float)y1, 0.0F).method_22915(g, h, k, f);
      class_286.method_43433(bufferBuilder.method_60800());
      RenderSystem.disableBlend();
   }

   public static class_243 worldToScreen(class_243 worldPos) {
      class_310 mc = class_310.method_1551();
      class_4184 camera = mc.field_1773.method_19418();
      Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
      Matrix4f modelViewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix());
      Vector4f pos = new Vector4f((float)(worldPos.field_1352 - camera.method_19326().field_1352), (float)(worldPos.field_1351 - camera.method_19326().field_1351), (float)(worldPos.field_1350 - camera.method_19326().field_1350), 1.0F);
      pos.mul(modelViewMatrix);
      pos.mul(projectionMatrix);
      if (pos.w == 0.0F) {
         return null;
      } else {
         pos.x /= pos.w;
         pos.y /= pos.w;
         pos.z /= pos.w;
         float screenX = (pos.x + 1.0F) / 2.0F * (float)mc.method_22683().method_4486();
         float screenY = (1.0F - pos.y) / 2.0F * (float)mc.method_22683().method_4502();
         return new class_243((double)screenX, (double)screenY, (double)pos.z);
      }
   }

   public static void drawItem(class_332 drawContext, class_1799 stack, int x, int y) {
      drawContext.method_51427(stack, x, y);
      drawContext.method_51431(Langr.mc.field_1772, stack, x, y);
   }

   public static void drawRect(class_4587 matrices, float x, float y, float width, float height, Color color) {
      int colorInt = color.getRGB();
      renderQuad(matrices, x, y, width, height, colorInt);
   }

   public static void drawRectWithOutline(class_4587 matrices, float x, float y, float width, float height, Color fillColor, Color outlineColor) {
      drawRect(matrices, x, y, width, height, fillColor);
      float outlineWidth = 1.0F;
      drawRect(matrices, x - outlineWidth, y - outlineWidth, outlineWidth, height + outlineWidth * 2.0F, outlineColor);
      drawRect(matrices, x + width, y - outlineWidth, outlineWidth, height + outlineWidth * 2.0F, outlineColor);
      drawRect(matrices, x - outlineWidth, y - outlineWidth, width + outlineWidth * 2.0F, outlineWidth, outlineColor);
      drawRect(matrices, x - outlineWidth, y + height, width + outlineWidth * 2.0F, outlineWidth, outlineColor);
   }

   public static class_243 worldSpaceToScreenSpace(class_243 worldPos) {
      return worldToScreen(worldPos);
   }

   public static void renderRoundedGradient(class_4587 matrices, Color color1, Color color2, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double samples, boolean horizontal) {
      Matrix4f matrix = matrices.method_23760().method_23761();
      setup();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      float centerX = (float)(x + (x2 - x) / (double)2.0F);
      float centerY = (float)(y + (y2 - y) / (double)2.0F);
      bufferBuilder.method_22918(matrix, centerX, centerY, 0.0F).method_22915((float)(color1.getRed() + color2.getRed()) / 2.0F / 255.0F, (float)(color1.getGreen() + color2.getGreen()) / 2.0F / 255.0F, (float)(color1.getBlue() + color2.getBlue()) / 2.0F / 255.0F, (float)(color1.getAlpha() + color2.getAlpha()) / 2.0F / 255.0F);
      double[][] map = new double[][]{{x2 - corner4, y2 - corner4, corner4}, {x2 - corner2, y + corner2, corner2}, {x + corner1, y + corner1, corner1}, {x + corner3, y2 - corner3, corner3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin = (float)(Math.sin((double)rad1) * rad);
            float cos = (float)(Math.cos((double)rad1) * rad);
            float px = (float)current[0] + sin;
            float py = (float)current[1] + cos;
            float progress;
            if (horizontal) {
               progress = (px - (float)x) / (float)(x2 - x);
            } else {
               progress = (py - (float)y) / (float)(y2 - y);
            }

            progress = Math.max(0.0F, Math.min(1.0F, progress));
            float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
            float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
            float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
            float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
            bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin = (float)(Math.sin((double)rad1) * rad);
         float cos = (float)(Math.cos((double)rad1) * rad);
         float px = (float)current[0] + sin;
         float py = (float)current[1] + cos;
         float progress;
         if (horizontal) {
            progress = (px - (float)x) / (float)(x2 - x);
         } else {
            progress = (py - (float)y) / (float)(y2 - y);
         }

         progress = Math.max(0.0F, Math.min(1.0F, progress));
         float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
         float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
         float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
         float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
         bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      cleanup();
   }

   public static void renderRoundedDiagonalGradient(class_4587 matrices, Color color1, Color color2, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double samples) {
      Matrix4f matrix = matrices.method_23760().method_23761();
      setup();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      float centerX = (float)(x + (x2 - x) / (double)2.0F);
      float centerY = (float)(y + (y2 - y) / (double)2.0F);
      bufferBuilder.method_22918(matrix, centerX, centerY, 0.0F).method_22915((float)(color1.getRed() + color2.getRed()) / 2.0F / 255.0F, (float)(color1.getGreen() + color2.getGreen()) / 2.0F / 255.0F, (float)(color1.getBlue() + color2.getBlue()) / 2.0F / 255.0F, (float)(color1.getAlpha() + color2.getAlpha()) / 2.0F / 255.0F);
      double[][] map = new double[][]{{x2 - corner4, y2 - corner4, corner4}, {x2 - corner2, y + corner2, corner2}, {x + corner1, y + corner1, corner1}, {x + corner3, y2 - corner3, corner3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin = (float)(Math.sin((double)rad1) * rad);
            float cos = (float)(Math.cos((double)rad1) * rad);
            float px = (float)current[0] + sin;
            float py = (float)current[1] + cos;
            float progress = (px - (float)x + (py - (float)y)) / ((float)(x2 - x) + (float)(y2 - y));
            progress = Math.max(0.0F, Math.min(1.0F, progress));
            float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
            float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
            float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
            float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
            bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin = (float)(Math.sin((double)rad1) * rad);
         float cos = (float)(Math.cos((double)rad1) * rad);
         float px = (float)current[0] + sin;
         float py = (float)current[1] + cos;
         float progress = (px - (float)x + (py - (float)y)) / ((float)(x2 - x) + (float)(y2 - y));
         progress = Math.max(0.0F, Math.min(1.0F, progress));
         float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
         float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
         float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
         float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
         bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      cleanup();
   }

   public static void renderRoundedRadialGradient(class_4587 matrices, Color color1, Color color2, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double samples) {
      Matrix4f matrix = matrices.method_23760().method_23761();
      setup();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      float centerX = (float)(x + (x2 - x) / (double)2.0F);
      float centerY = (float)(y + (y2 - y) / (double)2.0F);
      bufferBuilder.method_22918(matrix, centerX, centerY, 0.0F).method_22915((float)color1.getRed() / 255.0F, (float)color1.getGreen() / 255.0F, (float)color1.getBlue() / 255.0F, (float)color1.getAlpha() / 255.0F);
      double[][] map = new double[][]{{x2 - corner4, y2 - corner4, corner4}, {x2 - corner2, y + corner2, corner2}, {x + corner1, y + corner1, corner1}, {x + corner3, y2 - corner3, corner3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin = (float)(Math.sin((double)rad1) * rad);
            float cos = (float)(Math.cos((double)rad1) * rad);
            float px = (float)current[0] + sin;
            float py = (float)current[1] + cos;
            float distance = (float)Math.sqrt((double)((px - centerX) * (px - centerX) + (py - centerY) * (py - centerY)));
            float maxDistance = (float)Math.sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)) / 2.0F;
            float progress = Math.min(1.0F, distance / maxDistance);
            float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
            float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
            float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
            float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
            bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin = (float)(Math.sin((double)rad1) * rad);
         float cos = (float)(Math.cos((double)rad1) * rad);
         float px = (float)current[0] + sin;
         float py = (float)current[1] + cos;
         float distance = (float)Math.sqrt((double)((px - centerX) * (px - centerX) + (py - centerY) * (py - centerY)));
         float maxDistance = (float)Math.sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)) / 2.0F;
         float progress = Math.min(1.0F, distance / maxDistance);
         float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
         float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
         float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
         float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
         bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      cleanup();
   }

   public static void renderRoundedGradientOutline(class_332 context, Color color1, Color color2, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double width, double samples, boolean horizontal) {
      Matrix4f matrix = context.method_51448().method_23760().method_23761();
      setup();
      RenderSystem.setShader(class_757::method_34540);
      class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27380, class_290.field_1576);
      double[][] map = new double[][]{{x2 - corner4, y2 - corner4, corner4}, {x2 - corner2, y + corner2, corner2}, {x + corner1, y + corner1, corner1}, {x + corner3, y2 - corner3, corner3}};

      for(int i = 0; i < 4; ++i) {
         double[] current = map[i];
         double rad = current[2];

         for(double r = (double)i * (double)90.0F; r < (double)90.0F + (double)i * (double)90.0F; r += (double)90.0F / samples) {
            float rad1 = (float)Math.toRadians(r);
            float sin1 = (float)(Math.sin((double)rad1) * rad);
            float cos1 = (float)(Math.cos((double)rad1) * rad);
            float sin = (float)((double)sin1 * rad);
            float cos = (float)((double)cos1 * rad);
            float px = (float)current[0] + sin;
            float py = (float)current[1] + cos;
            float progress;
            if (horizontal) {
               progress = (px - (float)x) / (float)(x2 - x);
            } else {
               progress = (py - (float)y) / (float)(y2 - y);
            }

            progress = Math.max(0.0F, Math.min(1.0F, progress));
            float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
            float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
            float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
            float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
            bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
            bufferBuilder.method_22918(matrix, px + sin1 * (float)width, py + cos1 * (float)width, 0.0F).method_22915(r1, g1, b1, a1);
         }

         float rad1 = (float)Math.toRadians((double)90.0F + (double)i * (double)90.0F);
         float sin1 = (float)(Math.sin((double)rad1) * rad);
         float cos1 = (float)(Math.cos((double)rad1) * rad);
         float sin = (float)((double)sin1 * rad);
         float cos = (float)((double)cos1 * rad);
         float px = (float)current[0] + sin;
         float py = (float)current[1] + cos;
         float progress;
         if (horizontal) {
            progress = (px - (float)x) / (float)(x2 - x);
         } else {
            progress = (py - (float)y) / (float)(y2 - y);
         }

         progress = Math.max(0.0F, Math.min(1.0F, progress));
         float r1 = (float)color1.getRed() / 255.0F * (1.0F - progress) + (float)color2.getRed() / 255.0F * progress;
         float g1 = (float)color1.getGreen() / 255.0F * (1.0F - progress) + (float)color2.getGreen() / 255.0F * progress;
         float b1 = (float)color1.getBlue() / 255.0F * (1.0F - progress) + (float)color2.getBlue() / 255.0F * progress;
         float a1 = (float)color1.getAlpha() / 255.0F * (1.0F - progress) + (float)color2.getAlpha() / 255.0F * progress;
         bufferBuilder.method_22918(matrix, px, py, 0.0F).method_22915(r1, g1, b1, a1);
         bufferBuilder.method_22918(matrix, px + sin1 * (float)width, py + cos1 * (float)width, 0.0F).method_22915(r1, g1, b1, a1);
      }

      class_286.method_43433(bufferBuilder.method_60800());
      cleanup();
   }

   public static Color getMainColor() {
      return ClickMen.rainbow.getValue() ? Color.getHSBColor((float)(System.currentTimeMillis() % 2000L) / 2000.0F, 0.8F, 1.0F) : new Color((int)ClickMen.red.getValue(), (int)ClickMen.green.getValue(), (int)ClickMen.blue.getValue());
   }

   interface RenderAction {
      void run(class_287 var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, Matrix4f var12);
   }
}
