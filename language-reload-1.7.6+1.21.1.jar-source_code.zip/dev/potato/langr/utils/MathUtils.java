package dev.potato.langr.utils;

import java.util.Random;

public final class MathUtils {
   public static Random random = new Random(System.currentTimeMillis());

   public static double roundToDecimal(double n, double point) {
      return point * (double)Math.round(n / point);
   }

   public static int randomInt(int start, int bound) {
      return random.nextInt(bound - start) + start;
   }

   public static double smoothStepLerp(double delta, double start, double end) {
      delta = Math.max((double)0.0F, Math.min((double)1.0F, delta));
      double t = delta * delta * ((double)3.0F - (double)2.0F * delta);
      double value = start + (end - start) * t;
      return value;
   }

   public static double goodLerp(float delta, double start, double end) {
      int step = (int)Math.ceil(Math.abs(end - start) * (double)delta);
      return start < end ? Math.min(start + (double)step, end) : Math.max(start - (double)step, end);
   }

   public static double lerp(double delta, double start, double end) {
      return start + (end - start) * delta;
   }

   public static double approachValue(double speed, double current, double target) {
      double difference = target - current;
      return Math.abs(difference) < speed ? target : current + Math.signum(difference) * speed;
   }

   public static double roundToNearest(double value, double nearest) {
      return (double)Math.round(value / nearest) * nearest;
   }

   public static int clampInt(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   public static double clamp(double value, double min, double max) {
      return Math.max(min, Math.min(max, value));
   }

   public static double exponentialInterpolate(double current, double target, double factor) {
      return current + (target - current) * factor;
   }
}
