package dev.potato.langr.utils;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class EnchantmentUtil {
   public static boolean hasEnchantment(class_1799 itemStack, class_5321<?> registryKey) {
      if (itemStack.method_7960()) {
         return false;
      } else {
         Object2IntArrayMap<?> enchantmentMap = new Object2IntArrayMap();
         populateEnchantmentMap(itemStack, enchantmentMap);
         return containsEnchantment(enchantmentMap, registryKey);
      }
   }

   private static boolean containsEnchantment(Object2IntMap<?> enchantmentMap, class_5321<?> registryKey) {
      ObjectIterator var2 = enchantmentMap.keySet().iterator();

      while(var2.hasNext()) {
         Object enchantment = var2.next();
         if (((class_6880)enchantment).method_40225(registryKey)) {
            return true;
         }
      }

      return false;
   }

   public static void populateEnchantmentMap(class_1799 itemStack, Object2IntMap enchantmentMap) {
      enchantmentMap.clear();
      if (!itemStack.method_7960()) {
         Set<?> enchantments;
         if (itemStack.method_7909() == class_1802.field_8598) {
            enchantments = ((class_9304)itemStack.method_57824(class_9334.field_49643)).method_57539();
         } else {
            enchantments = itemStack.method_58657().method_57539();
         }

         for(Object enchantmentEntry : enchantments) {
            enchantmentMap.put(((Object2IntMap.Entry)enchantmentEntry).getKey(), ((Object2IntMap.Entry)enchantmentEntry).getIntValue());
         }
      }

   }
}
