package dev.potato.langr.utils;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;

public class TargetUtils {
   private static final class_310 mc = class_310.method_1551();

   public static class_1657 getClosest(double range) {
      return (class_1657)getValidPlayers(range).stream().min(Comparator.comparingDouble((player) -> (double)player.method_5739(mc.field_1724))).orElse((Object)null);
   }

   public static class_1657 getLowestHealth(double range) {
      return (class_1657)getValidPlayers(range).stream().min(Comparator.comparingDouble(class_1309::method_6032)).orElse((Object)null);
   }

   public static List<class_1657> getValidPlayers(double range) {
      return (List)((class_638)Objects.requireNonNull(mc.field_1687)).method_18456().stream().filter(TargetUtils::isValid).filter((p) -> p.method_5858(mc.field_1724) <= range * range).collect(Collectors.toList());
   }

   public static boolean isValid(class_1297 entity) {
      if (!(entity instanceof class_1309 living)) {
         return false;
      } else {
         return !living.method_29504() && !living.method_7325() && living != mc.field_1724 && living.method_6032() > 0.0F && !living.method_5767();
      }
   }

   public static boolean isInFov(class_1297 entity, float fov) {
      class_243 playerDir = mc.field_1724.method_5663();
      class_243 toTarget = entity.method_19538().method_1020(mc.field_1724.method_19538()).method_1029();
      double angle = Math.acos(playerDir.method_1026(toTarget)) * (180D / Math.PI);
      return angle <= (double)fov;
   }

   public static double getDistanceTo(class_1297 entity) {
      return mc.field_1724 != null ? (double)mc.field_1724.method_5739(entity) : (double)0.0F;
   }

   public static class_1657 getFovTarget(double range, float fov) {
      return (class_1657)getValidPlayers(range).stream().filter((e) -> isInFov(e, fov)).min(Comparator.comparingDouble((e) -> (double)e.method_5739(mc.field_1724))).orElse((Object)null);
   }

   public static class_1309 getClosestLivingEntity(float range, float fov) {
      return (class_1309)StreamSupport.stream(mc.field_1687.method_18112().spliterator(), false).filter((e) -> e instanceof class_1309).map((e) -> (class_1309)e).filter((e) -> isValid(e) && e.method_5858(mc.field_1724) <= (double)(range * range)).filter((e) -> isInFov(e, fov)).min(Comparator.comparingDouble((e) -> (double)e.method_5739(mc.field_1724))).orElse((Object)null);
   }
}
