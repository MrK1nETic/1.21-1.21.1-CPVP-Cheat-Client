package dev.potato.langr.utils;

import dev.potato.langr.Langr;
import java.util.ArrayList;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2248;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_9334;

public final class PInventoryUtils {
   public static PInventoryUtils INSTANCE = new PInventoryUtils();

   public ArrayList<Integer> findItemSlot(class_1792 item, boolean includeHotbar) {
      ArrayList<Integer> slots = new ArrayList();

      for(int i = includeHotbar ? 0 : 9; i < 36; ++i) {
         if (Langr.mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
            slots.add(i);
         }
      }

      return slots;
   }

   public void setCurrentSlot(int slot) {
      Langr.mc.field_1724.method_31548().field_7545 = slot;
   }

   public boolean isHoldingItem(class_1792 item) {
      return Langr.mc.field_1724.method_6047().method_7909() == item;
   }

   public Integer findBlockSlot(class_2248 block) {
      for(int i = 0; i < 9; ++i) {
         if (Langr.mc.field_1724.method_31548().method_5438(i).method_7909() == block.method_8389()) {
            return i;
         }
      }

      return null;
   }

   public Integer findPotion(int startSlot, int endSlot, class_1291 statusEffect) {
      for(int i = startSlot; i < endSlot; ++i) {
         class_1799 itemStack = Langr.mc.field_1724.method_31548().method_5438(i);
         if (itemStack.method_7909() == class_1802.field_8436 && (statusEffect == null || this.hasStatusEffect(itemStack, statusEffect))) {
            return i;
         }
      }

      return null;
   }

   public boolean hasStatusEffect(class_1799 itemStack, class_1291 statusEffect) {
      for(class_1293 statusEffectInstance : ((class_1844)itemStack.method_57824(class_9334.field_49651)).method_57397()) {
         if (statusEffectInstance.method_5579() == statusEffect) {
            return true;
         }
      }

      return false;
   }

   public boolean performSlotAction(int slotId, int button, class_1713 actionType) {
      class_437 var5 = Langr.mc.field_1755;
      if (var5 instanceof class_490 screen) {
         Langr.mc.field_1761.method_2906(((class_1723)screen.method_17577()).field_7763, slotId, button, actionType, Langr.mc.field_1724);
         return true;
      } else {
         return true;
      }
   }

   public boolean isHoldingOffhandItem(class_1792 item) {
      return Langr.mc.field_1724.method_6079().method_7909() == item;
   }

   public Integer findItemInHotbar(class_1792 item) {
      for(int i = 0; i < 9; ++i) {
         if (Langr.mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
            return i;
         }
      }

      return 0;
   }
}
