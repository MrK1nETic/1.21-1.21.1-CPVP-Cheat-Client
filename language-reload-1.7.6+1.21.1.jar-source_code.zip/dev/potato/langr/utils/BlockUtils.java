package dev.potato.langr.utils;

import dev.potato.langr.Langr;
import dev.potato.langr.utils.rotation.Rotation;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public final class BlockUtils {
   public static boolean isBlock(class_2338 pos, class_2248 block) {
      return Langr.mc.field_1687.method_8320(pos).method_26204() == block;
   }

   public static void rotateToBlock(class_2338 pos) {
      assert Langr.mc.field_1724 != null;

      Rotation rotation = RotationUtils.getDirection(Langr.mc.field_1724, pos.method_46558());
      Langr.mc.field_1724.method_36457((float)rotation.pitch());
      Langr.mc.field_1724.method_36456((float)rotation.yaw());
   }

   public static boolean isBlockAtPosition(class_2338 blockPos, class_2248 block) {
      return Langr.mc.field_1687.method_8320(blockPos).method_26204() == block;
   }

   public static void interactWithBlock(class_3965 blockHitResult, boolean shouldSwingHand) {
      class_1269 result = Langr.mc.field_1761.method_2896(Langr.mc.field_1724, class_1268.field_5808, blockHitResult);
      if (result.method_23665() && result.method_23666() && shouldSwingHand) {
         Langr.mc.field_1724.method_6104(class_1268.field_5808);
      }

   }

   public static boolean isAnchorCharged(class_2338 pos) {
      if (isBlock(pos, class_2246.field_23152)) {
         return (Integer)Langr.mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153) != 0;
      } else {
         return false;
      }
   }

   public static boolean isAnchorNotCharged(class_2338 pos) {
      if (isBlock(pos, class_2246.field_23152)) {
         return (Integer)Langr.mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153) == 0;
      } else {
         return false;
      }
   }

   public static boolean checkPosBlockClient(class_2338 block) {
      class_2338 up = block.method_10084();
      if (!Langr.mc.field_1687.method_22347(up)) {
         return false;
      } else {
         double x = (double)up.method_10263();
         double y = (double)up.method_10264();
         double z = (double)up.method_10260();
         List<class_1297> list = Langr.mc.field_1687.method_8335((class_1297)null, new class_238(x, y, z, x + (double)1.0F, y + (double)1.0F, z + (double)1.0F));
         list.removeIf((entity) -> entity instanceof class_1542);
         return list.isEmpty();
      }
   }

   public static Stream<class_2338> getAllInBoxStream(class_2338 from, class_2338 to) {
      class_2338 min = new class_2338(Math.min(from.method_10263(), to.method_10263()), Math.min(from.method_10264(), to.method_10264()), Math.min(from.method_10260(), to.method_10260()));
      class_2338 max = new class_2338(Math.max(from.method_10263(), to.method_10263()), Math.max(from.method_10264(), to.method_10264()), Math.max(from.method_10260(), to.method_10260()));
      Stream<class_2338> stream = Stream.iterate(min, (pos) -> {
         int x = pos.method_10263();
         int y = pos.method_10264();
         int z = pos.method_10260();
         ++x;
         if (x > max.method_10263()) {
            x = min.method_10263();
            ++y;
         }

         if (y > max.method_10264()) {
            y = min.method_10264();
            ++z;
         }

         if (z > max.method_10260()) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new class_2338(x, y, z);
         }
      });
      int limit = (max.method_10263() - min.method_10263() + 1) * (max.method_10264() - min.method_10264() + 1) * (max.method_10260() - min.method_10260() + 1);
      return stream.limit((long)limit);
   }
}
