package dev.potato.langr.utils;

public final class AnimationUtils {
   private final double originalValue;
   private double value;
   private double endValue;

   public AnimationUtils(double value) {
      this.value = value;
      this.originalValue = value;
   }

   public double animate(double delta, double end) {
      this.endValue = end;
      this.value = MathUtils.goodLerp((float)delta, this.value, end);
      return this.value;
   }

   public double getValue() {
      return this.value;
   }

   public double getOriginalValue() {
      return this.originalValue;
   }

   public double getEndValue() {
      return this.endValue;
   }

   public double getAnimationProgress() {
      return this.value / this.endValue;
   }

   public void reset(double delta) {
      this.value = MathUtils.smoothStepLerp(delta, this.value, this.originalValue);
   }
}
