package dev.potato.langr.utils;

import dev.potato.langr.Langr;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class PlayerUtils {
   private static final double diagonal = (double)1.0F / Math.sqrt((double)2.0F);
   private static final class_243 horizontalModDelAA = new class_243((double)0.0F, (double)0.0F, (double)0.0F);

   public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
      return Math.sqrt(squaredDistance(x1, y1, z1, x2, y2, z2));
   }

   public static double distanceTo(class_1297 entity) {
      return distanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
   }

   public static double distanceTo(class_2338 blockPos) {
      return distanceTo((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
   }

   public static double distanceTo(class_243 vec3d) {
      return distanceTo(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350);
   }

   public static double distanceTo(double x, double y, double z) {
      return Math.sqrt(squaredDistanceTo(x, y, z));
   }

   public static double squaredDistanceTo(class_1297 entity) {
      return squaredDistanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321());
   }

   public static double squaredDistanceTo(class_2338 blockPos) {
      return squaredDistanceTo((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
   }

   public static double squaredDistanceTo(double x, double y, double z) {
      return squaredDistance(Langr.mc.field_1724.method_23317(), Langr.mc.field_1724.method_23318(), Langr.mc.field_1724.method_23321(), x, y, z);
   }

   public static double squaredDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
      double dx = x1 - x2;
      double dy = y1 - y2;
      double dz = z1 - z2;
      return dx * dx + dy * dy + dz * dz;
   }

   public static boolean isWithin(class_1297 entity, double r) {
      return squaredDistanceTo(entity.method_23317(), entity.method_23318(), entity.method_23321()) <= r * r;
   }

   public static boolean isWithin(class_243 vec3d, double r) {
      return squaredDistanceTo(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350) <= r * r;
   }

   public static boolean isWithin(class_2338 blockPos, double r) {
      return squaredDistanceTo((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260()) <= r * r;
   }

   public static boolean isWithin(double x, double y, double z, double r) {
      return squaredDistanceTo(x, y, z) <= r * r;
   }

   public static boolean isInHole(boolean doubles) {
      if (Langr.mc.field_1724 != null && Langr.mc.field_1687 != null) {
         class_2338 blockPos = Langr.mc.field_1724.method_24515();
         int air = 0;

         for(class_2350 direction : class_2350.values()) {
            if (direction != class_2350.field_11036) {
               class_2680 state = Langr.mc.field_1687.method_8320(blockPos.method_10093(direction));
               if (state.method_26204().method_9520() < 600.0F) {
                  if (!doubles || direction == class_2350.field_11033) {
                     return false;
                  }

                  ++air;

                  for(class_2350 dir : class_2350.values()) {
                     if (dir != direction.method_10153() && dir != class_2350.field_11036) {
                        class_2680 blockState1 = Langr.mc.field_1687.method_8320(blockPos.method_10093(direction).method_10093(dir));
                        if (blockState1.method_26204().method_9520() < 600.0F) {
                           return false;
                        }
                     }
                  }
               }
            }
         }

         return air < 2;
      } else {
         return false;
      }
   }

   public static boolean isMoving() {
      return Langr.mc.field_1724.field_6250 != 0.0F || Langr.mc.field_1724.field_6212 != 0.0F;
   }

   public static boolean isModDeling() {
      return Langr.mc.field_1724.method_5624() && (Langr.mc.field_1724.field_6250 != 0.0F || Langr.mc.field_1724.field_6212 != 0.0F);
   }

   public static float getTotalHealth() {
      return Langr.mc.field_1724.method_6032() + Langr.mc.field_1724.method_6067();
   }

   public static boolean isAlive() {
      return Langr.mc.field_1724.method_5805() && !Langr.mc.field_1724.method_31481();
   }
}
