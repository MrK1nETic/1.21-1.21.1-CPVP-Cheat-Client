package dev.potato.langr.utils;

import java.util.Random;

public class RandomUtil {
   private final Random random = new Random();
   public static final RandomUtil INSTANCE = new RandomUtil();

   public Random getRandom() {
      return this.random;
   }

   public int randomInRange(int min, int max) {
      if (min > max) {
         int tmp = min;
         min = max;
         max = tmp;
      }

      return min + this.random.nextInt(max - min + 1);
   }

   public float randomInRange(float min, float max) {
      if (min > max) {
         float tmp = min;
         min = max;
         max = tmp;
      }

      return min + this.random.nextFloat() * (max - min);
   }

   public double randomInRange(double min, double max) {
      if (min > max) {
         double tmp = min;
         min = max;
         max = tmp;
      }

      return min + this.random.nextDouble() * (max - min);
   }
}
