package dev.potato.langr.utils;

import dev.potato.langr.Langr;
import net.minecraft.class_1657;
import net.minecraft.class_1802;

public final class PEntityUtils {
   public static PEntityUtils INSTANCE = new PEntityUtils();

   public class_1657 getPlayer() {
      class_1657 playerEntity = null;

      for(class_1657 player : Langr.mc.field_1687.method_18456()) {
         if (player.method_5805() && !player.equals(Langr.mc.field_1724)) {
            playerEntity = player;
         }
      }

      return playerEntity;
   }

   public boolean isUsingShield(class_1657 playerEntity) {
      return (playerEntity.method_6047().method_7909() == class_1802.field_8255 || playerEntity.method_6079().method_7909() == class_1802.field_8255) && playerEntity.method_6115();
   }
}
