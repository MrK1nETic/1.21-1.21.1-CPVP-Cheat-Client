package dev.potato.langr.config;

import dev.potato.langr.gui.ConfigScreen;
import java.io.File;
import net.fabricmc.loader.api.FabricLoader;

public class ConfigWriter implements Runnable {
   public static String[] fA = new String[4];
   public File file;
   public static String[] fz = new String[]{"=\u0013ü", "+¢H²", "Ë=õf\u009f\u0087v", "\u0012P&*"};

   public ConfigWriter() {
      String gameDir = FabricLoader.getInstance().getGameDir().toString();
      this.file = new File(gameDir + "/" + ConfigScreen.arg + ".json");
   }

   public void run() {
   }
}
