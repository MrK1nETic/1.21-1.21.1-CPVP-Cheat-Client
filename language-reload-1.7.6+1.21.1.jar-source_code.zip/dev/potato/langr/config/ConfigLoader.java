package dev.potato.langr.config;

import dev.potato.langr.gui.ConfigScreen;
import java.io.File;
import net.fabricmc.loader.api.FabricLoader;

public class ConfigLoader implements Runnable {
   public static String[] iF = new String[]{"\u0014Þ\u000e\u001aà\b\u0099", "\u0084(½ã"};
   public File file;
   public static String[] iG = new String[2];

   public ConfigLoader() {
      String gameDir = FabricLoader.getInstance().getGameDir().toString();
      this.file = new File(gameDir + "/" + ConfigScreen.arg + ".json");
   }

   public void run() {
   }
}
