package dev.potato.langr;

import java.io.IOException;
import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      try {
         new Langr();
      } catch (IOException | InterruptedException var2) {
      }

   }
}
