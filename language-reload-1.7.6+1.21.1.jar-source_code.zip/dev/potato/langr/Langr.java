package dev.potato.langr;

import dev.potato.langr.event.EventManager;
import dev.potato.langr.gui.ClickGui;
import dev.potato.langr.managers.FriendManager;
import dev.potato.langr.managers.ProfileManager;
import dev.potato.langr.module.ManagerClassA;
import dev.potato.langr.module.setting.ItemSetting;
import dev.potato.langr.utils.rotation.RotatorManager;
import java.io.File;
import java.net.URISyntaxException;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class Langr {
   public static class_310 mc;
   public static boolean BETA;
   public static Langr INSTANCE;
   public static ItemSetting renderBackground;
   public RotatorManager rotatorManager;
   public ProfileManager profileManager;
   public ManagerClassA moduleManager;
   public EventManager eventManager;
   public FriendManager friendManager;
   public String version = "";
   public boolean guiInitialized;
   public ClickGui clickGui;
   public class_437 previousScreen = null;
   public long lastModified;
   public File argonJar;
   public class_437 ClickGui;
   public boolean friendsWindowOnly = false;

   public Langr() {
      INSTANCE = this;
      this.eventManager = new EventManager();
      this.moduleManager = new ManagerClassA();
      this.clickGui = new ClickGui();
      this.rotatorManager = new RotatorManager();
      this.profileManager = new ProfileManager();
      this.friendManager = new FriendManager();
      this.getProfileManager().loadProfile();
      this.setLastModified();
      this.guiInitialized = false;
      mc = class_310.method_1551();
   }

   public ProfileManager getProfileManager() {
      return this.profileManager;
   }

   public ManagerClassA getManagerClassA() {
      return this.moduleManager;
   }

   public FriendManager getFriendManager() {
      return this.friendManager;
   }

   public EventManager getEventManager() {
      return this.eventManager;
   }

   public ClickGui getClickGui() {
      return this.clickGui;
   }

   public void resetModifiedDate() {
      this.argonJar.setLastModified(this.lastModified);
   }

   public String getVersion() {
      return this.version;
   }

   public void setLastModified() {
      try {
         this.argonJar = new File(Langr.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.lastModified = this.argonJar.lastModified();
      } catch (URISyntaxException var2) {
      }

   }

   public void openFriendsWindowOnly() {
      this.friendsWindowOnly = true;
      mc.method_1507(new ClickGui());
   }
}
