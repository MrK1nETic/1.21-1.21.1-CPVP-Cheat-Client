package dev.potato.langr.event.events;

import dev.potato.langr.event.Listener;
import net.minecraft.class_4587;

public interface RenderListener extends Listener {
   void onRender(class_4587 var1, float var2);
}
