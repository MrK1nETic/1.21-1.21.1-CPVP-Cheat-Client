package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface PlayerTickListener extends Listener {
   void onPlayerTick();

   public static class PlayerTickEvent extends Event<PlayerTickListener> {
      public void fire(ArrayList<PlayerTickListener> listeners) {
         listeners.forEach(PlayerTickListener::onPlayerTick);
      }

      public Class<PlayerTickListener> getListenerType() {
         return PlayerTickListener.class;
      }
   }
}
