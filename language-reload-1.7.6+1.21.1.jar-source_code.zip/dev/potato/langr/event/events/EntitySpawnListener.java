package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_2604;

public interface EntitySpawnListener extends Listener {
   void onEntitySpawn(EntitySpawnEvent var1);

   public static class EntitySpawnEvent extends CancellableEvent<EntitySpawnListener> {
      private final class_2604 packet;

      public EntitySpawnEvent(class_2604 packet) {
         this.packet = packet;
      }

      public class_2604 getPacket() {
         return this.packet;
      }

      public void fire(ArrayList<EntitySpawnListener> listeners) {
         listeners.forEach((e) -> e.onEntitySpawn(this));
      }

      public Class<EntitySpawnListener> getListenerType() {
         return EntitySpawnListener.class;
      }
   }
}
