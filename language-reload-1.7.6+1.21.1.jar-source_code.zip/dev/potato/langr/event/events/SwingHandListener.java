package dev.potato.langr.event.events;

import dev.potato.langr.event.Listener;

public interface SwingHandListener extends Listener {
   void onSwingHand(SwingHandEvent var1);
}
