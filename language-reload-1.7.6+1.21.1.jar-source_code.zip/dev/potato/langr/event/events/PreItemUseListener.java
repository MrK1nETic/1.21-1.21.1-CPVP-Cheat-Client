package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface PreItemUseListener extends Listener {
   void onPreItemUse(PreItemUseEvent var1);

   public static class PreItemUseEvent extends CancellableEvent<PreItemUseListener> {
      private final int cooldown;

      public PreItemUseEvent(int cooldown) {
         this.cooldown = cooldown;
      }

      public int getCooldown() {
         return this.cooldown;
      }

      public void fire(ArrayList<PreItemUseListener> listeners) {
         listeners.forEach((e) -> e.onPreItemUse(this));
      }

      public Class<PreItemUseListener> getListenerType() {
         return PreItemUseListener.class;
      }
   }
}
