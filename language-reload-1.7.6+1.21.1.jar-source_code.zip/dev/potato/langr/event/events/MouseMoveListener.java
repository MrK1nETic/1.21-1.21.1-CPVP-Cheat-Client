package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface MouseMoveListener extends Listener {
   void onMouseMove(MouseMoveEvent var1);

   public static class MouseMoveEvent extends CancellableEvent<MouseMoveListener> {
      public long windowHandle;
      public double x;
      public double y;

      public MouseMoveEvent(long windowHandle, double x, double y) {
         this.windowHandle = windowHandle;
         this.x = x;
         this.y = y;
      }

      public void fire(ArrayList<MouseMoveListener> listeners) {
         listeners.forEach((e) -> e.onMouseMove(this));
      }

      public Class<MouseMoveListener> getListenerType() {
         return MouseMoveListener.class;
      }
   }
}
