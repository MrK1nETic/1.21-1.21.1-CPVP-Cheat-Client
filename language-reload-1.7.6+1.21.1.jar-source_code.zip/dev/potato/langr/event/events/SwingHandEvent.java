package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import java.util.ArrayList;

public class SwingHandEvent extends CancellableEvent<SwingHandListener> {
   public void fire(ArrayList<SwingHandListener> listeners) {
      listeners.forEach((l) -> l.onSwingHand(this));
   }

   public Class<SwingHandListener> getListenerType() {
      return SwingHandListener.class;
   }
}
