package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface CameraUpdateListener extends Listener {
   void onCameraUpdate(CameraUpdateEvent var1);

   public static class CameraUpdateEvent extends CancellableEvent<CameraUpdateListener> {
      public double x;
      public double y;
      public double z;

      public CameraUpdateEvent(double x, double y, double z) {
         this.x = x;
         this.y = y;
         this.z = z;
      }

      public double getX() {
         return this.x;
      }

      public void setX(double x) {
         this.x = x;
      }

      public double getY() {
         return this.y;
      }

      public void setY(double y) {
         this.y = y;
      }

      public double getZ() {
         return this.z;
      }

      public void setZ(double z) {
         this.z = z;
      }

      public void fire(ArrayList<CameraUpdateListener> listeners) {
         listeners.forEach((l) -> l.onCameraUpdate(this));
      }

      public Class<CameraUpdateListener> getListenerType() {
         return CameraUpdateListener.class;
      }
   }
}
