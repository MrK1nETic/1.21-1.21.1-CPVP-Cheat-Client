package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface MovementPacketListener extends Listener {
   void onSendMovementPackets();

   public static class MovementPacketEvent extends Event<MovementPacketListener> {
      public void fire(ArrayList<MovementPacketListener> listeners) {
         listeners.forEach(MovementPacketListener::onSendMovementPackets);
      }

      public Class<MovementPacketListener> getListenerType() {
         return MovementPacketListener.class;
      }
   }
}
