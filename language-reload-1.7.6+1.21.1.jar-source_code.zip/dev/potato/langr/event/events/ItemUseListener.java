package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface ItemUseListener extends Listener {
   void onItemUse(ItemUseEvent var1);

   public static class ItemUseEvent extends CancellableEvent<ItemUseListener> {
      public void fire(ArrayList<ItemUseListener> listeners) {
         listeners.forEach((e) -> e.onItemUse(this));
      }

      public Class<ItemUseListener> getListenerType() {
         return ItemUseListener.class;
      }
   }
}
