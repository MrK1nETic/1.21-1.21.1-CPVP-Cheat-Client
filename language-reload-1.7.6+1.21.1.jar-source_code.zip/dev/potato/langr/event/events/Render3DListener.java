package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_4587;

public interface Render3DListener extends Listener {
   void onRender3D(Render3DEvent var1);

   public static class Render3DEvent extends Event<Render3DListener> {
      private static final Render3DEvent INSTANCE = new Render3DEvent();
      public class_4587 matrices;
      public float tickDelta;
      public double offsetX;
      public double offsetY;
      public double offsetZ;
      public double frameTime;

      public static Render3DEvent get(class_4587 matrices, float tickDelta, double offsetX, double offsetY, double offsetZ, double frameTime) {
         INSTANCE.matrices = matrices;
         INSTANCE.tickDelta = tickDelta;
         INSTANCE.offsetX = offsetX;
         INSTANCE.offsetY = offsetY;
         INSTANCE.offsetZ = offsetZ;
         INSTANCE.frameTime = frameTime;
         return INSTANCE;
      }

      public void fire(ArrayList<Render3DListener> listeners) {
         listeners.forEach((e) -> e.onRender3D(this));
      }

      public Class<Render3DListener> getListenerType() {
         return Render3DListener.class;
      }
   }
}
