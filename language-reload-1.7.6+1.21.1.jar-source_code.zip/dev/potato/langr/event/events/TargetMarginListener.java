package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public interface TargetMarginListener extends Listener {
   void onTargetMargin(TargetMarginEvent var1);

   public static class TargetMarginEvent extends CancellableEvent<TargetMarginListener> {
      public class_1297 entity;
      public CallbackInfoReturnable<Float> cir;

      public TargetMarginEvent(class_1297 entity, CallbackInfoReturnable<Float> cir) {
         this.entity = entity;
         this.cir = cir;
      }

      public void fire(ArrayList<TargetMarginListener> listeners) {
         listeners.forEach((e) -> e.onTargetMargin(this));
      }

      public Class<TargetMarginListener> getListenerType() {
         return TargetMarginListener.class;
      }
   }
}
