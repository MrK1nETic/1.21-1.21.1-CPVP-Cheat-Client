package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface TickListener extends Listener {
   void onTick();

   public static class TickEvent extends Event<TickListener> {
      public void fire(ArrayList<TickListener> listeners) {
         listeners.forEach(TickListener::onTick);
      }

      public Class<TickListener> getListenerType() {
         return TickListener.class;
      }
   }
}
