package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface AttackListener extends Listener {
   void onAttack(AttackEvent var1);

   public static class AttackEvent extends CancellableEvent<AttackListener> {
      public void fire(ArrayList<AttackListener> listeners) {
         listeners.forEach((e) -> e.onAttack(this));
      }

      public Class<AttackListener> getListenerType() {
         return AttackListener.class;
      }
   }
}
