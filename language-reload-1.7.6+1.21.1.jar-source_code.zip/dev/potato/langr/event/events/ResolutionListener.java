package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_1041;

public interface ResolutionListener extends Listener {
   void onResolution(ResolutionEvent var1);

   public static class ResolutionEvent extends Event<ResolutionListener> {
      public class_1041 window;

      public ResolutionEvent(class_1041 window) {
         this.window = window;
      }

      public void fire(ArrayList<ResolutionListener> listeners) {
         listeners.forEach((l) -> l.onResolution(this));
      }

      public Class<ResolutionListener> getListenerType() {
         return ResolutionListener.class;
      }
   }
}
