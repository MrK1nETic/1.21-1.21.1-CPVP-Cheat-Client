package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_2596;

public interface PacketReceiveListener extends Listener {
   void onPacketReceive(PacketReceiveEvent var1);

   public static class PacketReceiveEvent extends CancellableEvent<PacketReceiveListener> {
      public class_2596 packet;

      public PacketReceiveEvent(class_2596 packet) {
         this.packet = packet;
      }

      public void fire(ArrayList<PacketReceiveListener> listeners) {
         listeners.forEach((e) -> e.onPacketReceive(this));
      }

      public Class<PacketReceiveListener> getListenerType() {
         return PacketReceiveListener.class;
      }
   }
}
