package dev.potato.langr.event.events;

import dev.potato.langr.event.CancellableEvent;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface BlockBreakingListener extends Listener {
   void onBlockBreaking(BlockBreakingEvent var1);

   public static class BlockBreakingEvent extends CancellableEvent<BlockBreakingListener> {
      public void fire(ArrayList<BlockBreakingListener> listeners) {
         listeners.forEach((e) -> e.onBlockBreaking(this));
      }

      public Class<BlockBreakingListener> getListenerType() {
         return BlockBreakingListener.class;
      }
   }
}
