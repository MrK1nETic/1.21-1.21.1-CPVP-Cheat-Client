package dev.potato.langr.event.events;

import dev.potato.langr.event.Event;
import dev.potato.langr.event.Listener;
import java.util.ArrayList;

public interface ButtonListener extends Listener {
   void onButtonPress(ButtonEvent var1);

   public static class ButtonEvent extends Event<ButtonListener> {
      public int button;
      public int action;
      public long window;

      public ButtonEvent(int button, long window, int action) {
         this.button = button;
         this.window = window;
         this.action = action;
      }

      public void fire(ArrayList<ButtonListener> listeners) {
         listeners.forEach((e) -> e.onButtonPress(this));
      }

      public Class<ButtonListener> getListenerType() {
         return ButtonListener.class;
      }
   }
}
