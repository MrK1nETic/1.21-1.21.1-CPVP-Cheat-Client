package dev.potato.langr.gui;

import dev.potato.langr.Langr;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_746;

public class HudEditorGui extends class_437 {
   private final List<HudElement> hudElements = new ArrayList();
   private final class_437 parentScreen;
   private HudElement draggingElement = null;
   private double dragOffsetX;
   private double dragOffsetY;
   private boolean showGrid = true;
   private int gridSize = 20;

   public HudEditorGui(class_437 parentScreen) {
      super(class_2561.method_30163("HUD Editor"));
      this.parentScreen = parentScreen;
      this.initializeHudElements();
   }

   private void initializeHudElements() {
      this.hudElements.clear();
      List<Module> renderModules = Langr.INSTANCE.getManagerClassA().getModulesInCategory(Category.RENDER);
      System.out.println("Found " + renderModules.size() + " render modules");

      for(Module module : renderModules) {
         System.out.println("Checking module: " + String.valueOf(module.getName()));
         NumberSetting xSetting = null;
         NumberSetting ySetting = null;

         for(Setting<?> setting : module.getSettings()) {
            String settingName = setting.getName().toString().toLowerCase();
            System.out.println("  Setting: " + settingName);
            if (setting instanceof NumberSetting numberSetting) {
               if (!settingName.contains("x") || !settingName.contains("pos") && !settingName.equals("x")) {
                  if (settingName.contains("y") && (settingName.contains("pos") || settingName.equals("y"))) {
                     ySetting = numberSetting;
                     System.out.println("    Found Y setting: " + settingName);
                  }
               } else {
                  xSetting = numberSetting;
                  System.out.println("    Found X setting: " + settingName);
               }
            }
         }

         if (xSetting != null && ySetting != null) {
            int width = this.getModuleWidth(module);
            int height = this.getModuleHeight(module);
            System.out.println("  Adding module to HUD editor: " + String.valueOf(module.getName()) + " (" + width + "x" + height + ")");
            this.hudElements.add(new HudElement(module, width, height, this));
         } else {
            System.out.println("  Module " + String.valueOf(module.getName()) + " skipped - missing position settings");
         }
      }

      System.out.println("Total HUD elements: " + this.hudElements.size());
   }

   private int getModuleWidth(Module module) {
      short var10000;
      switch (module.getName().toString()) {
         case "Target HUD" -> var10000 = 300;
         case "HUD" -> var10000 = 200;
         case "Keybinds" -> var10000 = 120;
         case "Nametags" -> var10000 = 150;
         case "Spotify HUD" -> var10000 = 250;
         default -> var10000 = 100;
      }

      return var10000;
   }

   private int getModuleHeight(Module module) {
      short var10000;
      switch (module.getName().toString()) {
         case "Target HUD" -> var10000 = 180;
         case "HUD" -> var10000 = 150;
         case "Keybinds" -> var10000 = 100;
         case "Nametags" -> var10000 = 80;
         case "Spotify HUD" -> var10000 = 120;
         default -> var10000 = 60;
      }

      return var10000;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.method_25420(context, mouseX, mouseY, delta);
      if (this.showGrid) {
         this.renderGrid(context);
      }

      for(HudElement hudElement : this.hudElements) {
         hudElement.render(context, mouseX, mouseY, delta);
      }

      this.renderStatusEffects(context);
      this.renderUIOverlay(context, mouseX, mouseY);
      super.method_25394(context, mouseX, mouseY, delta);
   }

   public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, (new Color(40, 40, 40, 180)).getRGB());
   }

   private void renderGrid(class_332 context) {
      int screenWidth = this.field_22789;
      int screenHeight = this.field_22790;
      Color gridColor = new Color(100, 100, 100, 50);

      for(int x = 0; x < screenWidth; x += this.gridSize) {
         context.method_25294(x, 0, x + 1, screenHeight, gridColor.getRGB());
      }

      for(int y = 0; y < screenHeight; y += this.gridSize) {
         context.method_25294(0, y, screenWidth, y + 1, gridColor.getRGB());
      }

   }

   private void renderStatusEffects(class_332 context) {
      if (Langr.mc.field_1724 != null) {
         class_746 player = Langr.mc.field_1724;
         int n = this.field_22789;
         int n2 = this.field_22790;
         int effectsBoxWidth = 240;
         int lineHeight = 18;
         int effectCount = Math.max(1, player.method_6026().size());
         int effectsBoxHeight = 8 + effectCount * lineHeight + lineHeight + 8;
         int effectsBoxX = n - effectsBoxWidth - 10;
         int effectsBoxY = n2 - effectsBoxHeight - 10;
         RenderUtils.renderRoundedQuad(context.method_51448(), new Color(40, 40, 40, 180), (double)effectsBoxX, (double)effectsBoxY, (double)(effectsBoxX + effectsBoxWidth), (double)(effectsBoxY + effectsBoxHeight), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
         TextRenderer.drawString("Status Effects:", context, effectsBoxX + 10, effectsBoxY + 8, Color.WHITE.getRGB());
         int effectY = effectsBoxY + 8 + lineHeight;
         if (!player.method_6026().isEmpty()) {
            for(class_1293 effect : player.method_6026()) {
               String name = ((class_1291)effect.method_5579().comp_349()).method_5560().getString();
               int level = effect.method_5578() + 1;
               String levelStr = level > 1 ? " " + level : "";
               String effectName = name + levelStr;
               int color = ((class_1291)effect.method_5579().comp_349()).method_5556();
               int durationTicks = effect.method_5584();
               int seconds = durationTicks / 20;
               int minutes = seconds / 60;
               seconds %= 60;
               String durationStr = String.format("%d:%02d", minutes, seconds);
               TextRenderer.drawString(effectName, context, effectsBoxX + 10, effectY, color);
               int durationWidth = TextRenderer.getWidth(durationStr);
               TextRenderer.drawString(durationStr, context, effectsBoxX + effectsBoxWidth - 10 - durationWidth, effectY, Color.WHITE.getRGB());
               effectY += lineHeight;
            }
         } else {
            TextRenderer.drawString("None", context, effectsBoxX + 10, effectY, Color.LIGHT_GRAY.getRGB());
            int var10000 = effectY + lineHeight;
         }

      }
   }

   private void renderUIOverlay(class_332 context, int mouseX, int mouseY) {
      RenderUtils.renderRoundedQuad(context.method_51448(), new Color(30, 30, 30, 200), (double)0.0F, (double)0.0F, (double)this.field_22789, (double)40.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
      TextRenderer.drawString("HUD Editor", context, 10, 12, Color.WHITE.getRGB());
      String instructions = "Drag to move | Right-click to toggle | ESC to exit";
      int instructionsWidth = TextRenderer.getWidth(instructions);
      TextRenderer.drawString(instructions, context, this.field_22789 - instructionsWidth - 10, 12, (new Color(200, 200, 200)).getRGB());
      String gridText = this.showGrid ? "Hide Grid" : "Show Grid";
      int gridTextWidth = TextRenderer.getWidth(gridText);
      boolean gridHovered = mouseX >= 10 && mouseX <= 10 + gridTextWidth + 20 && mouseY >= 45 && mouseY <= 65;
      Color gridButtonColor = gridHovered ? new Color(60, 60, 60, 200) : new Color(40, 40, 40, 200);
      RenderUtils.renderRoundedQuad(context.method_51448(), gridButtonColor, (double)10.0F, (double)45.0F, (double)(10 + gridTextWidth + 20), (double)65.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
      TextRenderer.drawString(gridText, context, 20, 50, Color.WHITE.getRGB());
      String moduleCount = "Modules: " + this.hudElements.size();
      TextRenderer.drawString(moduleCount, context, 10, 70, (new Color(150, 150, 150)).getRGB());
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (button == 0 && mouseY >= (double)45.0F && mouseY <= (double)65.0F) {
         String gridText = this.showGrid ? "Hide Grid" : "Show Grid";
         int gridTextWidth = TextRenderer.getWidth(gridText);
         if (mouseX >= (double)10.0F && mouseX <= (double)(10 + gridTextWidth + 20)) {
            this.showGrid = !this.showGrid;
            return true;
         }
      }

      if (button == 0) {
         for(HudElement hudElement : this.hudElements) {
            if (hudElement.isHovered(mouseX, mouseY)) {
               this.draggingElement = hudElement;
               this.dragOffsetX = mouseX - (double)hudElement.getX();
               this.dragOffsetY = mouseY - (double)hudElement.getY();
               return true;
            }
         }
      }

      if (button == 1) {
         for(HudElement hudElement : this.hudElements) {
            if (hudElement.isHovered(mouseX, mouseY)) {
               hudElement.getModule().toggle();
               return true;
            }
         }
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.draggingElement = null;
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.draggingElement != null && button == 0) {
         int newX = (int)(mouseX - this.dragOffsetX);
         int newY = (int)(mouseY - this.dragOffsetY);
         if (this.showGrid) {
            newX = newX / this.gridSize * this.gridSize;
            newY = newY / this.gridSize * this.gridSize;
         }

         newX = Math.max(0, Math.min(this.field_22789 - this.draggingElement.getWidth(), newX));
         newY = Math.max(40, Math.min(this.field_22790 - this.draggingElement.getHeight(), newY));
         this.draggingElement.setPosition(newX, newY);
         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public void method_25419() {
      if (this.field_22787 != null) {
         this.field_22787.method_1507(this.parentScreen);
      }

   }

   public boolean method_25421() {
      return false;
   }

   public boolean isDraggingElement() {
      return this.draggingElement != null;
   }
}
