package dev.potato.langr.gui.friends;

import dev.potato.langr.Langr;
import dev.potato.langr.gui.ClickGui;
import dev.potato.langr.managers.FriendManager;
import dev.potato.langr.utils.TextRenderer;
import java.awt.Color;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1657;
import net.minecraft.class_332;

public class FriendsWindow {
   private int x;
   private int y;
   private int width;
   private int height;
   private boolean dragging = false;
   private int dragX;
   private int dragY;
   private final ClickGui parent;
   private int scrollOffset = 0;
   private static final int ENTRY_HEIGHT = 18;

   public FriendsWindow(int x, int y, int width, int height, ClickGui parent) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.parent = parent;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_51448().method_22903();
      context.method_51448().method_46416(0.0F, 0.0F, 100.0F);
      context.method_25294(this.x, this.y, this.x + this.width, this.y + this.height, (new Color(30, 30, 30, 200)).getRGB());
      TextRenderer.drawString("Friends Manager", context, this.x + 10, this.y + 8, Color.WHITE.getRGB());
      int midX = this.x + this.width / 2;
      context.method_25294(midX - 1, this.y + 28, midX + 1, this.y + this.height - 10, (new Color(60, 60, 60, 180)).getRGB());
      List<class_1657> onlinePlayers = Langr.mc.field_1687 == null ? List.of() : (List)Langr.mc.field_1687.method_18456().stream().filter((px) -> px != Langr.mc.field_1724).collect(Collectors.toList());
      FriendManager fm = Langr.INSTANCE.getFriendManager();
      List<class_1657> notFriends = (List)onlinePlayers.stream().filter((px) -> !fm.isFriend(px)).collect(Collectors.toList());
      Stream var10000 = onlinePlayers.stream();
      Objects.requireNonNull(fm);
      List<class_1657> friends = (List)var10000.filter(fm::isFriend).collect(Collectors.toList());
      TextRenderer.drawString("Online Players", context, this.x + 10, this.y + 30, Color.LIGHT_GRAY.getRGB());
      TextRenderer.drawString("Friends", context, midX + 10, this.y + 30, Color.LIGHT_GRAY.getRGB());
      int maxEntries = (this.height - 50) / 18;

      for(int i = 0; i < Math.min(notFriends.size(), maxEntries); ++i) {
         class_1657 p = (class_1657)notFriends.get(i + this.scrollOffset);
         String name = p.method_5477().getString();
         TextRenderer.drawString(name, context, this.x + 10, this.y + 50 + i * 18, Color.WHITE.getRGB());
         int btnX = this.x + this.width / 2 - 40;
         int btnY = this.y + 50 + i * 18 - 2;
         context.method_25294(btnX, btnY, btnX + 30, btnY + 14, (new Color(80, 180, 80, 200)).getRGB());
         TextRenderer.drawString("Add", context, btnX + 6, btnY + 2, Color.BLACK.getRGB());
      }

      for(int i = 0; i < Math.min(friends.size(), maxEntries); ++i) {
         class_1657 p = (class_1657)friends.get(i + this.scrollOffset);
         String name = p.method_5477().getString();
         TextRenderer.drawString(name, context, midX + 10, this.y + 50 + i * 18, Color.WHITE.getRGB());
         int btnX = midX + this.width / 2 - 60;
         int btnY = this.y + 50 + i * 18 - 2;
         context.method_25294(btnX, btnY, btnX + 50, btnY + 14, (new Color(180, 80, 80, 200)).getRGB());
         TextRenderer.drawString("Remove", context, btnX + 6, btnY + 2, Color.BLACK.getRGB());
      }

      context.method_51448().method_22909();
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0 && !this.dragging) {
         this.dragging = true;
         this.dragX = (int)(mouseX - (double)this.x);
         this.dragY = (int)(mouseY - (double)this.y);
      }

      int midX = this.x + this.width / 2;
      int maxEntries = (this.height - 50) / 18;
      List<class_1657> onlinePlayers = Langr.mc.field_1687 == null ? List.of() : (List)Langr.mc.field_1687.method_18456().stream().filter((p) -> p != Langr.mc.field_1724).collect(Collectors.toList());
      FriendManager fm = Langr.INSTANCE.getFriendManager();
      List<class_1657> notFriends = (List)onlinePlayers.stream().filter((p) -> !fm.isFriend(p)).collect(Collectors.toList());
      Stream var10000 = onlinePlayers.stream();
      Objects.requireNonNull(fm);
      List<class_1657> friends = (List)var10000.filter(fm::isFriend).collect(Collectors.toList());

      for(int i = 0; i < Math.min(notFriends.size(), maxEntries); ++i) {
         int btnX = this.x + this.width / 2 - 40;
         int btnY = this.y + 50 + i * 18 - 2;
         if (mouseX >= (double)btnX && mouseX <= (double)(btnX + 30) && mouseY >= (double)btnY && mouseY <= (double)(btnY + 14)) {
            fm.addClsend((class_1657)notFriends.get(i + this.scrollOffset));
         }
      }

      for(int i = 0; i < Math.min(friends.size(), maxEntries); ++i) {
         int btnX = midX + this.width / 2 - 60;
         int btnY = this.y + 50 + i * 18 - 2;
         if (mouseX >= (double)btnX && mouseX <= (double)(btnX + 50) && mouseY >= (double)btnY && mouseY <= (double)(btnY + 14)) {
            fm.removeFriend((class_1657)friends.get(i + this.scrollOffset));
         }
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0 && this.dragging) {
         this.dragging = false;
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.dragging) {
         this.x = (int)(mouseX - (double)this.dragX);
         this.y = (int)(mouseY - (double)this.dragY);
      }

   }

   public boolean isHovered(double mouseX, double mouseY) {
      return mouseX > (double)this.x && mouseX < (double)(this.x + this.width) && mouseY > (double)this.y && mouseY < (double)(this.y + this.height);
   }
}
