package dev.potato.langr.gui;

import dev.potato.langr.Langr;
import dev.potato.langr.gui.components.ModuleButton;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.modules.client.ClickMen;
import dev.potato.langr.utils.ColorUtils;
import dev.potato.langr.utils.MathUtils;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;

public final class Window {
   public List<ModuleButton> moduleButtons = new ArrayList();
   public int x;
   public int y;
   private final int width;
   private final int height;
   public Color currentColor;
   private final Category category;
   public boolean dragging;
   public boolean extended;
   private int dragX;
   private int dragY;
   private int prevX;
   private int prevY;
   public ClickGui parent;

   public Window(int x, int y, int width, int height, Category category, ClickGui parent) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.dragging = false;
      this.extended = true;
      this.height = height;
      this.category = category;
      this.parent = parent;
      this.prevX = x;
      this.prevY = y;
      int offset = height;

      for(Module module : new ArrayList(Langr.INSTANCE.getManagerClassA().getModulesInCategory(category))) {
         this.moduleButtons.add(new ModuleButton(this, module, offset));
         offset += height;
      }

   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      int toAlpha = 170;
      if (this.currentColor == null) {
         this.currentColor = new Color(0, 0, 0, 0);
      } else {
         this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
      }

      if (this.currentColor.getAlpha() != toAlpha) {
         this.currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, this.currentColor);
      }

      RenderUtils.renderRoundedQuad(context.method_51448(), this.currentColor, (double)this.prevX, (double)this.prevY, (double)(this.prevX + this.width), (double)(this.prevY + this.height), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
      int charOffset = this.prevX + this.width / 2;
      int totalWidth = TextRenderer.getWidth(this.category.name);
      int startX = charOffset - totalWidth / 2;
      if (ClickMen.customFont.getValue()) {
         context.method_51448().method_22903();
         context.method_51448().method_22905(1.0F, 1.0F, 1.0F);
         TextRenderer.drawString(this.category.name, context, startX, this.prevY + 6, Color.WHITE.getRGB());
         context.method_51448().method_22909();
      } else {
         TextRenderer.drawString(this.category.name, context, startX, this.prevY + 6, Color.WHITE.getRGB());
      }

      this.updateButtons(delta);

      for(ModuleButton moduleButton : this.moduleButtons) {
         moduleButton.render(context, mouseX, mouseY, delta);
      }

   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      for(ModuleButton moduleButton : this.moduleButtons) {
         moduleButton.keyPressed(keyCode, scanCode, modifiers);
      }

   }

   public void onGuiClose() {
      this.currentColor = null;

      for(ModuleButton moduleButton : this.moduleButtons) {
         moduleButton.onGuiClose();
      }

      this.dragging = false;
   }

   public boolean isDraggingAlready() {
      for(Window window : this.parent.windows) {
         if (window.dragging) {
            return true;
         }
      }

      return false;
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         switch (button) {
            case 0:
               if (!this.parent.isDraggingAlready()) {
                  this.dragging = true;
                  this.dragX = (int)(mouseX - (double)this.x);
                  this.dragY = (int)(mouseY - (double)this.y);
               }
               break;
            case 1:
               if (!this.dragging) {
               }
         }
      }

      if (this.extended) {
         for(ModuleButton moduleButton : this.moduleButtons) {
            moduleButton.mouseClicked(mouseX, mouseY, button);
         }
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.extended) {
         for(ModuleButton moduleButton : this.moduleButtons) {
            moduleButton.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
         }
      }

   }

   public void updateButtons(float delta) {
      int offset = this.height;

      for(ModuleButton moduleButton : this.moduleButtons) {
         moduleButton.animation.animate((double)0.5F * (double)delta, moduleButton.extended ? (double)(this.height * (moduleButton.settings.size() + 1)) : (double)this.height);
         double supHeight = moduleButton.animation.getValue();
         moduleButton.offset = offset;
         offset += (int)supHeight;
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0 && this.dragging) {
         this.dragging = false;
      }

      for(ModuleButton moduleButton : this.moduleButtons) {
         moduleButton.mouseReleased(mouseX, mouseY, button);
      }

   }

   public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.prevX = this.x;
      this.prevY = this.y;
      this.prevY = (int)((double)this.prevY + verticalAmount * (double)20.0F);
      this.setY((int)((double)this.y + verticalAmount * (double)20.0F));
   }

   public int getX() {
      return this.prevX;
   }

   public int getY() {
      return this.prevY;
   }

   public void setY(int y) {
      this.y = y;
   }

   public void setX(int x) {
      this.x = x;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public boolean isHovered(double mouseX, double mouseY) {
      return mouseX > (double)this.x && mouseX < (double)(this.x + this.width) && mouseY > (double)this.y && mouseY < (double)(this.y + this.height);
   }

   public boolean isPrevHovered(double mouseX, double mouseY) {
      return mouseX > (double)this.prevX && mouseX < (double)(this.prevX + this.width) && mouseY > (double)this.prevY && mouseY < (double)(this.prevY + this.height);
   }

   public void updatePosition(double mouseX, double mouseY, float delta) {
      this.prevX = this.x;
      this.prevY = this.y;
      if (this.dragging) {
         this.x = (int)MathUtils.goodLerp(0.3F * delta, this.isHovered(mouseX, mouseY) ? (double)this.x : (double)this.prevX, mouseX - (double)this.dragX);
         this.y = (int)MathUtils.goodLerp(0.3F * delta, this.isHovered(mouseX, mouseY) ? (double)this.y : (double)this.prevY, mouseY - (double)this.dragY);
      }

   }
}
