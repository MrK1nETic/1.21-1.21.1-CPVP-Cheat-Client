package dev.potato.langr.gui.components.settings;

import dev.potato.langr.gui.components.ModuleButton;
import dev.potato.langr.module.setting.MultiItemSetting;
import dev.potato.langr.utils.ColorUtil;
import dev.potato.langr.utils.MathUtil;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import dev.potato.langr.utils.Utils;
import java.awt.Color;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public final class ItemBox extends RenderableSetting {
   private final MultiItemSetting setting;
   private float hoverAnimation = 0.0F;
   private Color currentColor;
   private final Color TEXT_COLOR = new Color(230, 230, 230);
   private final Color HOVER_COLOR = new Color(255, 255, 255, 20);
   private final Color ITEM_BG = new Color(30, 30, 35);
   private final Color ITEM_BORDER = new Color(60, 60, 65);
   private final float CORNER_RADIUS = 4.0F;
   private final float HOVER_ANIMATION_SPEED = 0.25F;

   public ItemBox(ModuleButton moduleButton, MultiItemSetting setting, int n) {
      super(moduleButton, setting, n);
      this.setting = setting;
   }

   public void onUpdate() {
      Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
      if (this.currentColor == null) {
         this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
      } else {
         this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
      }

      if (this.currentColor.getAlpha() != 255) {
         this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
      }

      super.onUpdate();
   }

   public void render(class_332 drawContext, int n, int n2, float n3) {
      super.render(drawContext, n, n2, n3);
      this.updateAnimations(n, n2, n3);
      if (!this.parent.parent.dragging) {
         drawContext.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)((float)this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
      }

      int n4 = this.parentX() + 5;
      int n5 = this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2;
      TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, n4, n5 - 8, this.TEXT_COLOR.getRGB());
      int iconX = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
      int iconY = n5 - 11;
      int count = 0;

      for(class_1792 item : this.setting.getItems()) {
         if (count >= 5) {
            break;
         }

         RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.ITEM_BORDER, (double)iconX, (double)iconY, (double)(iconX + 22), (double)(iconY + 22), (double)4.0F, (double)4.0F, (double)4.0F, (double)4.0F, (double)50.0F);
         RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.ITEM_BG, (double)(iconX + 1), (double)(iconY + 1), (double)(iconX + 21), (double)(iconY + 21), (double)3.5F, (double)3.5F, (double)3.5F, (double)3.5F, (double)50.0F);
         drawContext.method_51427(new class_1799(item), iconX + 3, iconY + 3);
         iconX += 24;
         ++count;
      }

      if (this.setting.getItems().size() > 5) {
         TextRenderer.drawString("+" + (this.setting.getItems().size() - 5) + " more", drawContext, iconX, iconY + 6, (new Color(150, 150, 150, 200)).getRGB());
      }

      if (this.setting.getItems().isEmpty()) {
         TextRenderer.drawCenteredString("None", drawContext, iconX + 11, iconY + 4, (new Color(150, 150, 150, 200)).getRGB());
      }

   }

   private void updateAnimations(int n, int n2, float n3) {
      float n4;
      if (this.isHovered((double)n, (double)n2) && !this.parent.parent.dragging) {
         n4 = 1.0F;
      } else {
         n4 = 0.0F;
      }

      this.hoverAnimation = (float)MathUtil.exponentialInterpolate((double)this.hoverAnimation, (double)n4, (double)0.25F, (double)(n3 * 0.05F));
   }

   public void mouseClicked(double n, double n2, int n3) {
      if (this.isHovered(n, n2) && n3 == 0) {
         this.mc.method_1507(new ItemFilter(this.setting));
      }

      super.mouseClicked(n, n2, n3);
   }

   public void onGuiClose() {
      this.currentColor = null;
      this.hoverAnimation = 0.0F;
      super.onGuiClose();
   }
}
