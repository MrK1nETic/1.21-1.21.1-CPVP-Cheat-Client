package dev.potato.langr.gui.components.settings;

import dev.potato.langr.gui.components.ModuleButton;
import dev.potato.langr.module.setting.ColorSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;

public class ColorBox extends RenderableSetting {
   private final ColorSetting colorSetting;
   private boolean expanded = false;
   private boolean draggingHue = false;
   private boolean draggingSaturation = false;
   private boolean draggingValue = false;
   private boolean draggingAlpha = false;
   private float hue = 0.0F;
   private float saturation = 1.0F;
   private float value = 1.0F;
   private float alpha = 1.0F;

   public ColorBox(ModuleButton parent, Setting<?> setting, int offset) {
      super(parent, setting, offset);
      this.colorSetting = (ColorSetting)setting;
      Color currentColor = this.colorSetting.getColor();
      float[] hsv = Color.RGBtoHSB(currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue(), (float[])null);
      this.hue = hsv[0];
      this.saturation = hsv[1];
      this.value = hsv[2];
      this.alpha = (float)currentColor.getAlpha() / 255.0F;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      Color currentColor = this.colorSetting.getColor();
      context.method_25294(this.parentX() + 5, this.parentY() + this.parentOffset() + this.offset + 5, this.parentX() + 25, this.parentY() + this.parentOffset() + this.offset + 20, currentColor.getRGB());
      context.method_49601(this.parentX() + 5, this.parentY() + this.parentOffset() + this.offset + 5, this.parentX() + 25, this.parentY() + this.parentOffset() + this.offset + 20, -16777216);
      TextRenderer.drawString(this.colorSetting.getName().toString(), context, this.parentX() + 30, this.parentY() + this.parentOffset() + this.offset + 9, (new Color(245, 245, 245, 255)).getRGB());
      String arrow = this.expanded ? "▼" : "▶";
      TextRenderer.drawString(arrow, context, this.parentX() + this.parentWidth() - 20, this.parentY() + this.parentOffset() + this.offset + 9, (new Color(245, 245, 245, 255)).getRGB());
      if (this.expanded) {
         this.renderColorPicker(context, mouseX, mouseY);
      }

   }

   private void renderColorPicker(class_332 context, int mouseX, int mouseY) {
      int pickerY = this.parentY() + this.parentOffset() + this.offset + 25;
      int pickerHeight = 120;
      context.method_25294(this.parentX(), pickerY, this.parentX() + this.parentWidth(), pickerY + pickerHeight, -13816531);
      context.method_49601(this.parentX(), pickerY, this.parentX() + this.parentWidth(), pickerY + pickerHeight, -16777216);
      int hueY = pickerY + 10;

      for(int i = 0; i < this.parentWidth() - 20; ++i) {
         float hueValue = (float)i / (float)(this.parentWidth() - 20);
         Color hueColor = Color.getHSBColor(hueValue, 1.0F, 1.0F);
         context.method_25294(this.parentX() + 10 + i, hueY, this.parentX() + 11 + i, hueY + 15, hueColor.getRGB());
      }

      context.method_49601(this.parentX() + 10, hueY, this.parentX() + this.parentWidth() - 10, hueY + 15, -16777216);
      int hueIndicatorX = this.parentX() + 10 + (int)(this.hue * (float)(this.parentWidth() - 20));
      context.method_25294(hueIndicatorX - 2, hueY - 2, hueIndicatorX + 2, hueY + 17, -1);
      int svX = this.parentX() + 10;
      int svY = pickerY + 35;
      int svSize = Math.min(this.parentWidth() - 20, 60);

      for(int sx = 0; sx < svSize; ++sx) {
         for(int sy = 0; sy < svSize; ++sy) {
            float s = (float)sx / (float)svSize;
            float v = 1.0F - (float)sy / (float)svSize;
            Color svColor = Color.getHSBColor(this.hue, s, v);
            context.method_25294(svX + sx, svY + sy, svX + sx + 1, svY + sy + 1, svColor.getRGB());
         }
      }

      context.method_49601(svX, svY, svX + svSize, svY + svSize, -16777216);
      int svIndicatorX = svX + (int)(this.saturation * (float)svSize);
      int svIndicatorY = svY + (int)((1.0F - this.value) * (float)svSize);
      context.method_25294(svIndicatorX - 2, svIndicatorY - 2, svIndicatorX + 2, svIndicatorY + 2, -1);
      int alphaY = pickerY + 105;
      Color currentColor = this.colorSetting.getColor();

      for(int i = 0; i < this.parentWidth() - 20; ++i) {
         float alphaValue = (float)i / (float)(this.parentWidth() - 20);
         Color alphaColor = new Color((int)((float)currentColor.getRed() * alphaValue), (int)((float)currentColor.getGreen() * alphaValue), (int)((float)currentColor.getBlue() * alphaValue), (int)(255.0F * alphaValue));
         context.method_25294(this.parentX() + 10 + i, alphaY, this.parentX() + 11 + i, alphaY + 10, alphaColor.getRGB());
      }

      context.method_49601(this.parentX() + 10, alphaY, this.parentX() + this.parentWidth() - 10, alphaY + 10, -16777216);
      int alphaIndicatorX = this.parentX() + 10 + (int)(this.alpha * (float)(this.parentWidth() - 20));
      context.method_25294(alphaIndicatorX - 2, alphaY - 2, alphaIndicatorX + 2, alphaY + 12, -1);
      Color newColor = this.getCurrentColor();
      context.method_25294(this.parentX() + this.parentWidth() - 30, pickerY + 35, this.parentX() + this.parentWidth() - 10, pickerY + 55, newColor.getRGB());
      context.method_49601(this.parentX() + this.parentWidth() - 30, pickerY + 35, this.parentX() + this.parentWidth() - 10, pickerY + 55, -16777216);
   }

   private Color getCurrentColor() {
      Color hsvColor = Color.getHSBColor(this.hue, this.saturation, this.value);
      return new Color(hsvColor.getRed(), hsvColor.getGreen(), hsvColor.getBlue(), (int)(this.alpha * 255.0F));
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         if (mouseX >= (double)(this.parentX() + this.parentWidth() - 20) && mouseX <= (double)(this.parentX() + this.parentWidth()) && mouseY >= (double)(this.parentY() + this.parentOffset() + this.offset) && mouseY <= (double)(this.parentY() + this.parentOffset() + this.offset + 20)) {
            this.expanded = !this.expanded;
            return;
         }

         if (this.expanded) {
            this.handleColorPickerClick(mouseX, mouseY);
         }
      }

      super.mouseClicked(mouseX, mouseY, button);
   }

   private void handleColorPickerClick(double mouseX, double mouseY) {
      int pickerY = this.parentY() + this.parentOffset() + this.offset + 25;
      if (mouseY >= (double)(pickerY + 10) && mouseY <= (double)(pickerY + 25) && mouseX >= (double)(this.parentX() + 10) && mouseX <= (double)(this.parentX() + this.parentWidth() - 10)) {
         this.draggingHue = true;
         this.updateHueFromMouse(mouseX);
      }

      int svX = this.parentX() + 10;
      int svY = pickerY + 35;
      int svSize = Math.min(this.parentWidth() - 20, 60);
      if (mouseX >= (double)svX && mouseX <= (double)(svX + svSize) && mouseY >= (double)svY && mouseY <= (double)(svY + svSize)) {
         this.draggingSaturation = true;
         this.draggingValue = true;
         this.updateSaturationValueFromMouse(mouseX, mouseY);
      }

      if (mouseY >= (double)(pickerY + 105) && mouseY <= (double)(pickerY + 115) && mouseX >= (double)(this.parentX() + 10) && mouseX <= (double)(this.parentX() + this.parentWidth() - 10)) {
         this.draggingAlpha = true;
         this.updateAlphaFromMouse(mouseX);
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.draggingHue) {
         this.updateHueFromMouse(mouseX);
      }

      if (this.draggingSaturation || this.draggingValue) {
         this.updateSaturationValueFromMouse(mouseX, mouseY);
      }

      if (this.draggingAlpha) {
         this.updateAlphaFromMouse(mouseX);
      }

      super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      this.draggingHue = false;
      this.draggingSaturation = false;
      this.draggingValue = false;
      this.draggingAlpha = false;
      super.mouseReleased(mouseX, mouseY, button);
   }

   private void updateHueFromMouse(double mouseX) {
      float newHue = Math.max(0.0F, Math.min(1.0F, (float)(mouseX - (double)(this.parentX() + 10)) / (float)(this.parentWidth() - 20)));
      if (newHue != this.hue) {
         this.hue = newHue;
         this.updateColor();
      }

   }

   private void updateSaturationValueFromMouse(double mouseX, double mouseY) {
      int svX = this.parentX() + 10;
      int svY = this.parentY() + this.parentOffset() + this.offset + 40;
      int svSize = Math.min(this.parentWidth() - 20, 60);
      float newSaturation = Math.max(0.0F, Math.min(1.0F, (float)(mouseX - (double)svX) / (float)svSize));
      float newValue = Math.max(0.0F, Math.min(1.0F, 1.0F - (float)(mouseY - (double)svY) / (float)svSize));
      if (newSaturation != this.saturation || newValue != this.value) {
         this.saturation = newSaturation;
         this.value = newValue;
         this.updateColor();
      }

   }

   private void updateAlphaFromMouse(double mouseX) {
      float newAlpha = Math.max(0.0F, Math.min(1.0F, (float)(mouseX - (double)(this.parentX() + 10)) / (float)(this.parentWidth() - 20)));
      if (newAlpha != this.alpha) {
         this.alpha = newAlpha;
         this.updateColor();
      }

   }

   private void updateColor() {
      Color newColor = this.getCurrentColor();
      this.colorSetting.setColor(newColor);
   }
}
