package dev.potato.langr.gui.components.settings;

import dev.potato.langr.module.setting.MultiItemSetting;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import dev.potato.langr.utils.Utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class ItemFilter extends class_437 {
   private final MultiItemSetting setting;
   private String searchQuery;
   private final List<class_1792> allItems;
   private List<class_1792> filteredItems;
   private int scrollOffset;
   private final Set<class_1792> selectedItems;
   private final int ITEMS_PER_ROW = 11;
   private final int MAX_ROWS_VISIBLE = 6;
   private int selectedIndex;
   private final int ITEM_SIZE = 40;
   private final int ITEM_SPACING = 8;

   public ItemFilter(MultiItemSetting setting) {
      super(class_2561.method_43473());
      this.setting = setting;
      this.searchQuery = "";
      this.scrollOffset = 0;
      this.selectedIndex = -1;
      this.selectedItems = new HashSet(setting.getItems());
      this.allItems = new ArrayList();
      class_7923.field_41178.forEach((item) -> {
         if (item != class_1802.field_8162) {
            this.allItems.add(item);
         }

      });
      this.filteredItems = new ArrayList(this.allItems);
   }

   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
      RenderUtils.unscaledProjection();
      int width = class_310.method_1551().method_22683().method_4480();
      int height = class_310.method_1551().method_22683().method_4507();
      int n6 = (width - 580) / 2;
      int n7 = (height - 450) / 2;
      int n8 = n6 + 20;
      int n9 = n7 + 50;
      int n10 = n6 + 20;
      int n11 = n9 + 30 + 15;
      int n12 = 450 - (n11 - n7) - 60;
      drawContext.method_25294(0, 0, width, height, (new Color(0, 0, 0, 180)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), (double)n6, (double)n7, (double)(n6 + 580), (double)(n7 + 450), (double)8.0F, (double)8.0F, (double)8.0F, (double)8.0F, (double)20.0F);
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), (double)n6, (double)n7, (double)(n6 + 580), (double)(n7 + 30), (double)8.0F, (double)8.0F, (double)0.0F, (double)0.0F, (double)20.0F);
      drawContext.method_25294(n6, n7 + 30, n6 + 580, n7 + 31, Utils.getMainColor(255, 1).getRGB());
      String var10000 = String.valueOf(this.setting.getName());
      TextRenderer.drawCenteredString("Select Items: " + var10000, drawContext, n6 + 290, n7 + 8, (new Color(245, 245, 245, 255)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), (double)n8, (double)n9, (double)(n8 + 540), (double)(n9 + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), (double)n8, (double)n9, (double)(n8 + 540), (double)(n9 + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)1.0F, (double)20.0F);
      String s = System.currentTimeMillis() % 1000L > 500L ? "|" : "";
      TextRenderer.drawString("Search: " + this.searchQuery + s, drawContext, n8 + 10, n9 + 9, (new Color(200, 200, 200, 255)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(25, 25, 30, 255), (double)n10, (double)n11, (double)(n10 + 540), (double)(n11 + n12), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      double ceil = Math.ceil((double)this.filteredItems.size() / (double)11.0F);
      int max = Math.max(0, (int)ceil - 6);
      this.scrollOffset = Math.min(this.scrollOffset, max);
      if ((int)ceil > 6) {
         int barX = n10 + 540 - 6 - 5;
         int barY = n11 + 5;
         int barHeight = n12 - 10;
         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 150), (double)barX, (double)barY, (double)(barX + 6), (double)(barY + barHeight), (double)3.0F, (double)3.0F, (double)3.0F, (double)3.0F, (double)20.0F);
         float n16 = (float)this.scrollOffset / (float)max;
         float max2 = Math.max(40.0F, (float)barHeight * (6.0F / (float)ceil));
         int n17 = barY + (int)(((float)barHeight - max2) * n16);
         RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), (double)barX, (double)n17, (double)(barX + 6), (double)(n17 + (int)max2), (double)3.0F, (double)3.0F, (double)3.0F, (double)3.0F, (double)20.0F);
      }

      int start = this.scrollOffset * 11;
      int end = Math.min(start + Math.min(this.filteredItems.size(), 66), this.filteredItems.size());

      for(int i = start; i < end; ++i) {
         int col = (i - start) % 11;
         int row = (i - start) / 11;
         int itemX = n10 + 5 + col * 48;
         int itemY = n11 + 5 + row * 48;
         class_1792 item = (class_1792)this.filteredItems.get(i);
         boolean selected = this.selectedItems.contains(item);
         Color mainColor = selected ? Utils.getMainColor(100, 1) : new Color(35, 35, 40, 255);
         RenderUtils.renderRoundedQuad(drawContext.method_51448(), mainColor, (double)itemX, (double)itemY, (double)(itemX + 40), (double)(itemY + 40), (double)4.0F, (double)4.0F, (double)4.0F, (double)4.0F, (double)20.0F);
         drawContext.method_51427(new class_1799(item), itemX + 3, itemY + 3);
         if (selected) {
            RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(200, 1), (double)itemX, (double)itemY, (double)(itemX + 40), (double)(itemY + 40), (double)4.0F, (double)4.0F, (double)4.0F, (double)4.0F, (double)2.0F, (double)20.0F);
         }
      }

      if (this.filteredItems.isEmpty()) {
         TextRenderer.drawCenteredString("No items found", drawContext, n10 + 270, n11 + n12 / 2 - 10, (new Color(150, 150, 150, 200)).getRGB());
      }

      int btnY = n7 + 450 - 45;
      int saveX = n6 + 580 - 80 - 20;
      int cancelX = saveX - 80 - 10;
      int resetX = cancelX - 80 - 10;
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), (double)saveX, (double)btnY, (double)(saveX + 80), (double)(btnY + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      TextRenderer.drawCenteredString("Save", drawContext, saveX + 40, btnY + 8, (new Color(245, 245, 245, 255)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(60, 60, 65, 255), (double)cancelX, (double)btnY, (double)(cancelX + 80), (double)(btnY + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      TextRenderer.drawCenteredString("Cancel", drawContext, cancelX + 40, btnY + 8, (new Color(245, 245, 245, 255)).getRGB());
      RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(70, 40, 40, 255), (double)resetX, (double)btnY, (double)(resetX + 80), (double)(btnY + 30), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)20.0F);
      TextRenderer.drawCenteredString("Reset", drawContext, resetX + 40, btnY + 8, (new Color(245, 245, 245, 255)).getRGB());
      RenderUtils.scaledProjection();
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      double scale = class_310.method_1551().method_22683().method_4495();
      double unscaledMouseX = mouseX * scale;
      double unscaledMouseY = mouseY * scale;
      int width = class_310.method_1551().method_22683().method_4480();
      int height = class_310.method_1551().method_22683().method_4507();
      int n6 = (width - 580) / 2;
      int n7 = (height - 450) / 2;
      int n8 = n6 + 20;
      int n9 = n7 + 50;
      int n10 = n6 + 20;
      int n11 = n9 + 30 + 15;
      int n12 = 450 - (n11 - n7) - 60;
      int btnY = n7 + 450 - 45;
      int saveX = n6 + 580 - 80 - 20;
      int cancelX = saveX - 80 - 10;
      int resetX = cancelX - 80 - 10;
      if (this.isInBounds(unscaledMouseX, unscaledMouseY, saveX, btnY, 80, 30)) {
         this.setting.setItems(this.selectedItems);
         class_310.method_1551().method_1507((class_437)null);
         return true;
      } else if (this.isInBounds(unscaledMouseX, unscaledMouseY, cancelX, btnY, 80, 30)) {
         class_310.method_1551().method_1507((class_437)null);
         return true;
      } else if (this.isInBounds(unscaledMouseX, unscaledMouseY, resetX, btnY, 80, 30)) {
         this.selectedItems.clear();
         return true;
      } else {
         int start = this.scrollOffset * 11;
         int end = Math.min(start + Math.min(this.filteredItems.size(), 66), this.filteredItems.size());

         for(int i = start; i < end; ++i) {
            int col = (i - start) % 11;
            int row = (i - start) / 11;
            int itemX = n10 + 5 + col * 48;
            int itemY = n11 + 5 + row * 48;
            if (this.isInBounds(unscaledMouseX, unscaledMouseY, itemX, itemY, 40, 40)) {
               class_1792 item = (class_1792)this.filteredItems.get(i);
               if (this.selectedItems.contains(item)) {
                  this.selectedItems.remove(item);
               } else {
                  this.selectedItems.add(item);
               }

               return true;
            }
         }

         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double amount, double delta) {
      double scale = class_310.method_1551().method_22683().method_4495();
      double var10000 = mouseX * scale;
      var10000 = mouseY * scale;
      double ceil = Math.ceil((double)this.filteredItems.size() / (double)11.0F);
      int max = Math.max(0, (int)ceil - 6);
      if (amount > (double)0.0F) {
         this.scrollOffset = Math.max(0, this.scrollOffset - 1);
         return true;
      } else if (amount < (double)0.0F) {
         this.scrollOffset = Math.min(max, this.scrollOffset + 1);
         return true;
      } else {
         return false;
      }
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         class_310.method_1551().method_1507((class_437)null);
         return true;
      } else if (keyCode == 259) {
         if (!this.searchQuery.isEmpty()) {
            this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
            this.updateFilteredItems();
         }

         return true;
      } else {
         return super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   public boolean method_25400(char chr, int modifiers) {
      this.searchQuery = this.searchQuery + chr;
      this.updateFilteredItems();
      return true;
   }

   private void updateFilteredItems() {
      if (this.searchQuery.isEmpty()) {
         this.filteredItems = new ArrayList(this.allItems);
      } else {
         this.filteredItems = (List)this.allItems.stream().filter((item) -> item.method_7848().getString().toLowerCase().contains(this.searchQuery.toLowerCase())).collect(Collectors.toList());
      }

      this.scrollOffset = 0;
   }

   private boolean isInBounds(double mouseX, double mouseY, int x, int y, int w, int h) {
      return mouseX >= (double)x && mouseX <= (double)(x + w) && mouseY >= (double)y && mouseY <= (double)(y + h);
   }

   public boolean method_25422() {
      return false;
   }
}
