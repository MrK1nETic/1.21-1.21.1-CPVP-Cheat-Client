package dev.potato.langr.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.potato.langr.Langr;
import dev.potato.langr.gui.Window;
import dev.potato.langr.gui.components.settings.CheckBox;
import dev.potato.langr.gui.components.settings.ColorBox;
import dev.potato.langr.gui.components.settings.ItemBox;
import dev.potato.langr.gui.components.settings.KeybindBox;
import dev.potato.langr.gui.components.settings.MinMaxSlider;
import dev.potato.langr.gui.components.settings.ModeBox;
import dev.potato.langr.gui.components.settings.RenderableSetting;
import dev.potato.langr.gui.components.settings.Slider;
import dev.potato.langr.gui.components.settings.StringBox;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.ColorSetting;
import dev.potato.langr.module.setting.KeybindSetting;
import dev.potato.langr.module.setting.MinMaxSetting;
import dev.potato.langr.module.setting.ModeSetting;
import dev.potato.langr.module.setting.MultiItemSetting;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.module.setting.StringSetting;
import dev.potato.langr.utils.AnimationUtils;
import dev.potato.langr.utils.ColorUtils;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import dev.potato.langr.utils.Utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public final class ModuleButton {
   public List<RenderableSetting> settings = new ArrayList();
   public Window parent;
   public Module module;
   public int offset;
   public boolean extended;
   public int settingOffset;
   public Color currentColor;
   public Color defaultColor;
   public Color currentAlpha;
   public AnimationUtils animation;

   public ModuleButton(Window parent, Module module, int offset) {
      this.defaultColor = Color.WHITE;
      this.animation = new AnimationUtils((double)0.0F);
      this.parent = parent;
      this.module = module;
      this.offset = offset;
      this.extended = false;
      this.settingOffset = parent.getHeight();

      for(Setting<?> setting : module.getSettings()) {
         if (setting instanceof BooleanSetting booleanSetting) {
            this.settings.add(new CheckBox(this, booleanSetting, this.settingOffset));
         } else if (setting instanceof NumberSetting numberSetting) {
            this.settings.add(new Slider(this, numberSetting, this.settingOffset));
         } else if (setting instanceof ModeSetting<?> modeSetting) {
            this.settings.add(new ModeBox(this, modeSetting, this.settingOffset));
         } else if (setting instanceof KeybindSetting keybindSetting) {
            this.settings.add(new KeybindBox(this, keybindSetting, this.settingOffset));
         } else if (setting instanceof StringSetting stringSetting) {
            this.settings.add(new StringBox(this, stringSetting, this.settingOffset));
         } else if (setting instanceof MinMaxSetting minMaxSetting) {
            this.settings.add(new MinMaxSlider(this, minMaxSetting, this.settingOffset));
         } else if (setting instanceof ColorSetting colorSetting) {
            this.settings.add(new ColorBox(this, colorSetting, this.settingOffset));
         } else if (setting instanceof MultiItemSetting multiItemSetting) {
            this.settings.add(new ItemBox(this, multiItemSetting, this.settingOffset));
         }

         this.settingOffset += parent.getHeight();
      }

   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.parent.getY() + this.offset <= class_310.method_1551().method_22683().method_4507()) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.onUpdate();
         }

         if (this.currentColor == null) {
            this.currentColor = new Color(0, 0, 0, 0);
         } else {
            this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
         }

         int toAlpha = 170;
         this.currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, this.currentColor);
         Color toColor = this.module.isEnabled() ? Utils.getMainColor(255, Langr.INSTANCE.getManagerClassA().getModulesInCategory(this.module.getCategory()).indexOf(this.module)) : Color.WHITE;
         if (this.defaultColor != toColor) {
            this.defaultColor = ColorUtils.smoothColorTransition(0.1F, toColor, this.defaultColor);
         }

         if (this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) != this) {
            RenderUtils.renderRoundedQuad(context.method_51448(), this.currentColor, (double)this.parent.getX(), (double)(this.parent.getY() + this.offset), (double)(this.parent.getX() + this.parent.getWidth()), (double)(this.parent.getY() + this.parent.getHeight() + this.offset), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
         } else {
            RenderUtils.renderRoundedQuad(context.method_51448(), this.currentColor, (double)this.parent.getX(), (double)(this.parent.getY() + this.offset), (double)(this.parent.getX() + this.parent.getWidth()), (double)(this.parent.getY() + this.parent.getHeight() + this.offset), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
         }

         CharSequence nameChars = this.module.getName();
         int textLeftX = this.parent.getX() + 8;
         TextRenderer.drawString(nameChars, context, textLeftX, this.parent.getY() + this.offset + 8, this.defaultColor.getRGB());
         boolean hasRenderableSettings = this.module.getSettings().stream().anyMatch((setting) -> setting instanceof BooleanSetting || setting instanceof NumberSetting || setting instanceof ModeSetting || setting instanceof StringSetting || setting instanceof MinMaxSetting || setting instanceof ColorSetting);
         if (hasRenderableSettings) {
            String arrow = this.extended ? "v" : "^";
            int arrowWidth = TextRenderer.getWidth(arrow);
            class_4587 matrices = context.method_51448();
            matrices.method_22903();
            float scale = 1.1F;
            matrices.method_22905(scale, scale, 1.0F);
            int arrowX = (int)((float)(this.parent.getX() + this.parent.getWidth() - arrowWidth - 6) / scale);
            int arrowY = (int)((float)(this.parent.getY() + this.offset + 10) / scale);
            TextRenderer.drawString(arrow, context, arrowX, arrowY, Color.WHITE.getRGB());
            matrices.method_22909();
         }

         this.renderHover(context, mouseX, mouseY, delta);
         this.renderSettings(context, mouseX, mouseY, delta);

         for(RenderableSetting renderableSetting : this.settings) {
            if (this.extended) {
               renderableSetting.renderDescription(context, mouseX, mouseY, delta);
            }
         }

         if (this.isHovered((double)mouseX, (double)mouseY) && !this.parent.dragging) {
            CharSequence chars = this.module.getDescription();
            int tw = TextRenderer.getWidth(chars);
            int parentCenter = Langr.mc.method_22683().method_4489() / 2;
            int textCenter = parentCenter - tw / 2;
            RenderUtils.renderRoundedQuad(context.method_51448(), new Color(100, 100, 100, 100), (double)(textCenter - 5), (double)Langr.mc.method_22683().method_4506() / (double)2.0F + (double)294.0F, (double)(textCenter + tw + 5), (double)Langr.mc.method_22683().method_4506() / (double)2.0F + (double)318.0F, (double)3.0F, (double)10.0F);
            TextRenderer.drawString(chars, context, textCenter, Langr.mc.method_22683().method_4506() / 2 + 300, Color.WHITE.getRGB());
         }

      }
   }

   private void renderHover(class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.parent.dragging) {
         int toHoverAlpha = this.isHovered((double)mouseX, (double)mouseY) ? 15 : 0;
         if (this.currentAlpha == null) {
            this.currentAlpha = new Color(255, 255, 255, toHoverAlpha);
         } else {
            this.currentAlpha = new Color(255, 255, 255, this.currentAlpha.getAlpha());
         }

         if (this.currentAlpha.getAlpha() != toHoverAlpha) {
            this.currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, this.currentAlpha);
         }

         RenderUtils.renderRoundedQuad(context.method_51448(), this.currentAlpha, (double)this.parent.getX(), (double)(this.parent.getY() + this.offset), (double)(this.parent.getX() + this.parent.getWidth()), (double)(this.parent.getY() + this.parent.getHeight() + this.offset), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
      }

   }

   private void renderSettings(class_332 context, int mouseX, int mouseY, float delta) {
      int scissorX = this.parent.getX();
      int scissorY = (int)((double)Langr.mc.method_22683().method_4507() - ((double)(this.parent.getY() + this.offset) + this.animation.getValue()));
      int scissorWidth = this.parent.getWidth();
      int scissorHeight = (int)this.animation.getValue();
      RenderSystem.enableScissor(scissorX, scissorY, scissorWidth, scissorHeight);

      for(RenderableSetting renderableSetting : this.settings) {
         if (this.animation.getValue() > (double)this.parent.getHeight()) {
            renderableSetting.render(context, mouseX, mouseY, delta);
         }
      }

      for(RenderableSetting renderableSetting : this.settings) {
         if (this.animation.getValue() > (double)this.parent.getHeight()) {
            if (renderableSetting instanceof Slider) {
               Slider slider = (Slider)renderableSetting;
               RenderUtils.renderCircle(context.method_51448(), new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context.method_51448(), slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
            } else if (renderableSetting instanceof MinMaxSlider) {
               MinMaxSlider slider = (MinMaxSlider)renderableSetting;
               RenderUtils.renderCircle(context.method_51448(), new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetMinX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context.method_51448(), slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetMinX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
               RenderUtils.renderCircle(context.method_51448(), new Color(0, 0, 0, 170), (double)slider.parentX() + Math.max(slider.lerpedOffsetMaxX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)6.0F, 15);
               RenderUtils.renderCircle(context.method_51448(), slider.currentColor1.brighter(), (double)slider.parentX() + Math.max(slider.lerpedOffsetMaxX, (double)2.5F), (double)(slider.parentY() + slider.offset + slider.parentOffset()) + (double)27.5F, (double)5.0F, 15);
            }
         }
      }

      RenderSystem.disableScissor();
   }

   public void onExtend() {
      for(ModuleButton moduleButton : this.parent.moduleButtons) {
         moduleButton.extended = false;
      }

   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      for(RenderableSetting setting : this.settings) {
         setting.keyPressed(keyCode, scanCode, modifiers);
      }

   }

   public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.extended) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
         }
      }

   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY)) {
         if (button == 0) {
            this.module.toggle();
         }

         if (button == 1) {
            if (this.module.getSettings().isEmpty()) {
               return;
            }

            if (!this.extended) {
               this.onExtend();
            }

            this.extended = !this.extended;
         }
      }

      if (this.extended) {
         for(RenderableSetting renderableSetting : this.settings) {
            renderableSetting.mouseClicked(mouseX, mouseY, button);
         }
      }

   }

   public void onGuiClose() {
      this.currentAlpha = null;
      this.currentColor = null;

      for(RenderableSetting renderableSetting : this.settings) {
         renderableSetting.onGuiClose();
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      for(RenderableSetting renderableSetting : this.settings) {
         renderableSetting.mouseReleased(mouseX, mouseY, button);
      }

   }

   public boolean isHovered(double mouseX, double mouseY) {
      return mouseX > (double)this.parent.getX() && mouseX < (double)(this.parent.getX() + this.parent.getWidth()) && mouseY > (double)(this.parent.getY() + this.offset) && mouseY < (double)(this.parent.getY() + this.offset + this.parent.getHeight());
   }
}
