package dev.potato.langr.gui;

import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_332;

public class HudElement {
   private final Module module;
   private final NumberSetting xSetting;
   private final NumberSetting ySetting;
   private final int width;
   private final int height;
   private final HudEditorGui parent;

   public HudElement(Module module, int width, int height, HudEditorGui parent) {
      this.module = module;
      this.width = width;
      this.height = height;
      this.parent = parent;
      NumberSetting xSetting = null;
      NumberSetting ySetting = null;

      for(Setting<?> setting : module.getSettings()) {
         String settingName = setting.getName().toString().toLowerCase();
         if (setting instanceof NumberSetting numberSetting) {
            if (!settingName.contains("x") || !settingName.contains("pos") && !settingName.equals("x")) {
               if (settingName.contains("y") && (settingName.contains("pos") || settingName.equals("y"))) {
                  ySetting = numberSetting;
               }
            } else {
               xSetting = numberSetting;
            }
         }
      }

      this.xSetting = xSetting;
      this.ySetting = ySetting;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.xSetting != null && this.ySetting != null) {
         int x = this.xSetting.getIntValue();
         int y = this.ySetting.getIntValue();
         Color backgroundColor = this.module.isEnabled() ? new Color(65, 185, 255, 100) : new Color(100, 100, 100, 100);
         RenderUtils.renderRoundedQuad(context.method_51448(), backgroundColor, (double)x, (double)y, (double)(x + this.width), (double)(y + this.height), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
         Color borderColor = this.module.isEnabled() ? new Color(65, 185, 255, 200) : new Color(150, 150, 150, 200);
         RenderUtils.renderRoundedOutline(context, borderColor, (double)(x - 1), (double)(y - 1), (double)(x + this.width + 1), (double)(y + this.height + 1), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)1.5F, (double)10.0F);
         String moduleName = this.module.getName().toString();
         int textX = x + this.width / 2 - TextRenderer.getWidth(moduleName) / 2;
         int textY = y + 5;
         Color textColor = this.module.isEnabled() ? Color.WHITE : new Color(200, 200, 200);
         TextRenderer.drawString(moduleName, context, textX, textY, textColor.getRGB());
         String status = this.module.isEnabled() ? "ON" : "OFF";
         int statusWidth = TextRenderer.getWidth(status);
         int statusX = x + this.width / 2 - statusWidth / 2;
         int statusY = y + this.height - 20;
         Color statusColor = this.module.isEnabled() ? new Color(100, 255, 100) : new Color(255, 100, 100);
         TextRenderer.drawString(status, context, statusX, statusY, statusColor.getRGB());
         if (this.isHovered((double)mouseX, (double)mouseY)) {
            RenderUtils.renderRoundedOutline(context, new Color(255, 255, 0, 150), (double)(x - 2), (double)(y - 2), (double)(x + this.width + 2), (double)(y + this.height + 2), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)2.0F, (double)10.0F);
            String tooltip = "Right-click to toggle";
            int tooltipWidth = TextRenderer.getWidth(tooltip);
            int tooltipX = mouseX + 5;
            int tooltipY = mouseY - 20;
            if (tooltipX + tooltipWidth > this.parent.field_22789) {
               tooltipX = mouseX - tooltipWidth - 5;
            }

            if (tooltipY < 0) {
               tooltipY = mouseY + 10;
            }

            RenderUtils.renderRoundedQuad(context.method_51448(), new Color(0, 0, 0, 200), (double)(tooltipX - 2), (double)(tooltipY - 2), (double)(tooltipX + tooltipWidth + 2), (double)(tooltipY + 12), (double)3.0F, (double)3.0F, (double)3.0F, (double)3.0F, (double)5.0F);
            TextRenderer.drawString(tooltip, context, tooltipX, tooltipY, Color.WHITE.getRGB());
         }

      }
   }

   public boolean isHovered(double mouseX, double mouseY) {
      if (this.xSetting != null && this.ySetting != null) {
         int x = this.xSetting.getIntValue();
         int y = this.ySetting.getIntValue();
         return mouseX >= (double)x && mouseX <= (double)(x + this.width) && mouseY >= (double)y && mouseY <= (double)(y + this.height);
      } else {
         return false;
      }
   }

   public void setPosition(int x, int y) {
      if (this.xSetting != null && this.ySetting != null) {
         this.xSetting.setValue((double)x);
         this.ySetting.setValue((double)y);
      }

   }

   public int getX() {
      return this.xSetting != null ? this.xSetting.getIntValue() : 0;
   }

   public int getY() {
      return this.ySetting != null ? this.ySetting.getIntValue() : 0;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public Module getModule() {
      return this.module;
   }
}
