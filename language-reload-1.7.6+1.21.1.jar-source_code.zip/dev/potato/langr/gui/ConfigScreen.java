package dev.potato.langr.gui;

import dev.potato.langr.utils.TimerUtils;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {
   public TimerUtils timer = new TimerUtils();
   public static String arg = "";
   public boolean hoveredDelete;
   public boolean hovered;
   public static String[] ge = new String[13];
   public boolean upper;
   public boolean deleted;
   public boolean listening;
   public boolean hoveredSave;
   public boolean loaded;
   public boolean hoveredLoad;
   public boolean saved;
   public int fpsTimer;
   public int clock;
   public static String[] gd = new String[]{"c", "\u0092-q(\u008bÀ", "Öw\u009f\n9", "\u00835ªW\u0005\u0096", "\u0092HN\u0087\u0094z", "ù }\u0096\u0080ý", "»Ü_b", "\u0086ù\u009f\u0017/", ".Òeö9r", "ÚÝÿ]×'", "W\u001fN\u0005", "\u0007i\u0006hn", "á~sç"};

   public ConfigScreen() {
      super(class_2561.method_30163(""));
   }
}
