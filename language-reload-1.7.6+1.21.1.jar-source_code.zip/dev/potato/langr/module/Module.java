package dev.potato.langr.module;

import dev.potato.langr.Langr;
import dev.potato.langr.event.EventManager;
import dev.potato.langr.module.setting.Setting;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_310;

public abstract class Module implements Serializable {
   public final EventManager eventManager;
   private final List<Setting<?>> settings;
   protected static class_310 mc = class_310.method_1551();
   private CharSequence name;
   private CharSequence description;
   private boolean enabled;
   private int key;
   private Category category;
   private boolean showOptions;

   public Module(CharSequence name, CharSequence description, int key, Category category) {
      this.eventManager = Langr.INSTANCE.eventManager;
      this.settings = new ArrayList();
      this.showOptions = false;
      this.name = name;
      this.description = description;
      this.enabled = false;
      this.key = key;
      this.category = category;
   }

   public void toggle() {
      this.enabled = !this.enabled;
      if (this.enabled) {
         this.onEnable();
      } else {
         this.onDisable();
      }

   }

   public CharSequence getName() {
      return this.name;
   }

   public void setName(CharSequence name) {
      this.name = name;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
      if (enabled) {
         this.onEnable();
      } else {
         this.onDisable();
      }

   }

   public CharSequence getDescription() {
      return this.description;
   }

   public void setDescription(CharSequence description) {
      this.description = description;
   }

   public int getKey() {
      return this.key;
   }

   public void setKey(int key) {
      this.key = key;
   }

   public Category getCategory() {
      return this.category;
   }

   public void setCategory(Category category) {
      this.category = category;
   }

   public List<Setting<?>> getSettings() {
      return this.settings;
   }

   public boolean showOptions() {
      return this.showOptions;
   }

   public void toggleShowOptions() {
      this.showOptions = !this.showOptions;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void addSetting(Setting<?> setting) {
      this.settings.add(setting);
   }

   public void addSettings(Setting<?>... settings) {
      this.settings.addAll(Arrays.asList(settings));
   }

   public void setEnabledStatus(boolean enabled) {
      this.enabled = enabled;
   }
}
