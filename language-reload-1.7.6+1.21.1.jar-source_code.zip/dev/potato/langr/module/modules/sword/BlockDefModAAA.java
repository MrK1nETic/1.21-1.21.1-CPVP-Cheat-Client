package dev.potato.langr.module.modules.sword;

import dev.potato.langr.event.events.AttackListener;
import dev.potato.langr.event.events.TickListener;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.EncryptedString;
import dev.potato.langr.utils.InventoryUtils;
import dev.potato.langr.utils.MouseSimulation;
import dev.potato.langr.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class BlockDefModAAA extends Module implements TickListener, AttackListener {
   private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), (double)0.0F, (double)20.0F, (double)0.0F, (double)1.0F);
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), (double)0.0F, (double)20.0F, (double)0.0F, (double)1.0F);
   private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
   private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
   private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), false);
   private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);
   int previousSlot;
   int hitClock;
   int switchClock;

   public BlockDefModAAA() {
      super(EncryptedString.of("shield"), EncryptedString.of("Automatically disables your opponents shield"), -1, Category.SWORD);
      this.addSettings(new Setting[]{this.switchDelay, this.hitDelay, this.switchBack, this.stun, this.clickSimulate, this.requireHoldAxe});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.eventManager.add(AttackListener.class, this);
      this.hitClock = this.hitDelay.getValueInt();
      this.switchClock = this.switchDelay.getValueInt();
      this.previousSlot = -1;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (mc.field_1755 == null) {
         if (!this.requireHoldAxe.getValue() || mc.field_1724.method_6047().method_7909() instanceof class_1743) {
            class_239 var2 = mc.field_1765;
            if (var2 instanceof class_3966) {
               class_3966 entityHit = (class_3966)var2;
               class_1297 entity = entityHit.method_17782();
               if (mc.field_1724.method_6115()) {
                  return;
               }

               if (entity instanceof class_1657) {
                  class_1657 player = (class_1657)entity;
                  if (WorldUtils.isShieldFacingAway(player)) {
                     return;
                  }

                  if (player.method_24518(class_1802.field_8255) && player.method_6039()) {
                     if (this.switchClock > 0) {
                        if (this.previousSlot == -1) {
                           this.previousSlot = mc.field_1724.method_31548().field_7545;
                        }

                        --this.switchClock;
                        return;
                     }

                     if (InventoryUtils.selectAxe()) {
                        if (this.hitClock > 0) {
                           --this.hitClock;
                        } else {
                           if (this.clickSimulate.getValue()) {
                              MouseSimulation.mouseClick(0);
                           }

                           WorldUtils.hitEntity(player, true);
                           if (this.stun.getValue()) {
                              if (this.clickSimulate.getValue()) {
                                 MouseSimulation.mouseClick(0);
                              }

                              WorldUtils.hitEntity(player, true);
                           }

                           this.hitClock = this.hitDelay.getValueInt();
                           this.switchClock = this.switchDelay.getValueInt();
                        }
                     }
                  } else if (this.previousSlot != -1) {
                     if (this.switchBack.getValue()) {
                        InventoryUtils.setInvSlot(this.previousSlot);
                     }

                     this.previousSlot = -1;
                  }
               }
            }

         }
      }
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 0) != 1) {
         event.cancel();
      }

   }
}
