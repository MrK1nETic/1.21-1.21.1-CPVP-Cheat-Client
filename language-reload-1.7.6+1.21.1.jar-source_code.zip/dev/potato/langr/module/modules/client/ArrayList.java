package dev.potato.langr.module.modules.client;

import dev.potato.langr.Langr;
import dev.potato.langr.event.events.HudListener;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.KeybindSetting;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.EncryptedString;
import dev.potato.langr.utils.RenderUtils;
import dev.potato.langr.utils.TextRenderer;
import dev.potato.langr.utils.Utils;
import java.awt.Color;
import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.class_332;

public final class ArrayList extends Module implements HudListener {
   public BooleanSetting showDetails = new BooleanSetting(EncryptedString.of("Show Details"), false);
   public KeybindSetting bind = new KeybindSetting(EncryptedString.of("Bind"), -1, false);
   public BooleanSetting glow = new BooleanSetting(EncryptedString.of("Glow"), false);
   public static String[] dW = new String[]{"b", "6\u008cÝÌþ\u0098", "«ª,_Ô\b", "c\u009f", "²\u001fò\u0014Ú<", "\u0004hs)â", "y", "Asèø", "_°YñÀ×G", "êþ\u000bÍÃ", "\n®D", "ÖÚû\u0010úë", "\u0085\u000f,I\u0016", "£«D", "8pÍW\u001e", "É\r\u0096ê\u0016", "×", "`!Z6é=pç", "P%u ", "¤\u0098å^.û", "¹W\u001f", "wÐ¬¸Z]", "@M~\u0004\t\u001a", "â÷ "};
   public NumberSetting g = new NumberSetting(EncryptedString.of("Green"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public static String[] dX = new String[24];
   public NumberSetting r = new NumberSetting(EncryptedString.of("Red"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public BooleanSetting showBind = new BooleanSetting(EncryptedString.of("Show Bind"), false);
   public BooleanSetting font = new BooleanSetting(EncryptedString.of("Custom Font"), false);
   public BooleanSetting lowerCase = new BooleanSetting(EncryptedString.of("Lower Case"), false);
   public NumberSetting b = new NumberSetting(EncryptedString.of("Blue"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public BooleanSetting rgb = new BooleanSetting(EncryptedString.of("RGB"), false);
   public NumberSetting xPosition = new NumberSetting(EncryptedString.of("X Position"), (double)0.0F, (double)1920.0F, (double)100.0F, (double)1.0F);
   public NumberSetting yPosition = new NumberSetting(EncryptedString.of("Y Position"), (double)0.0F, (double)1080.0F, (double)100.0F, (double)1.0F);

   public ArrayList() {
      super(EncryptedString.of("ArrayList"), EncryptedString.of("Shows enabled modules on screen"), -1, Category.CLIENT);
      this.addSettings(new Setting[]{this.bind, this.rgb, this.r, this.g, this.b, this.showDetails, this.lowerCase, this.glow, this.font, this.showBind, this.xPosition, this.yPosition});
   }

   public void onEnable() {
      this.eventManager.add(HudListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(HudListener.class, this);
      super.onDisable();
   }

   public void onRenderHud(HudListener.HudEvent event) {
      if (this.isEnabled()) {
         class_332 context = event.context;
         List<Module> enabledModules = new java.util.ArrayList(Langr.INSTANCE.getManagerClassA().getEnabledModules());
         if (!enabledModules.isEmpty()) {
            enabledModules.sort((a, b) -> {
               String nameA = a.getName() != null ? a.getName().toString() : "Unknown";
               String nameB = b.getName() != null ? b.getName().toString() : "Unknown";
               return Integer.compare(TextRenderer.getWidth(nameB), TextRenderer.getWidth(nameA));
            });
            int x = (int)this.xPosition.getValue();
            int y = (int)this.yPosition.getValue();
            int padding = 2;
            int fontHeight = 9;
            RenderUtils.unscaledProjection();

            for(int i = 0; i < enabledModules.size(); ++i) {
               Module module = (Module)enabledModules.get(i);
               String moduleName = module.getName() != null ? module.getName().toString() : EncryptedString.of("Unknown").toString();
               if (this.lowerCase.getValue()) {
                  moduleName = moduleName.toLowerCase();
               }

               int textWidth = TextRenderer.getWidth(moduleName);
               int boxHeight = fontHeight + 4;
               int totalWidth = textWidth + 5;
               String mainBindText = null;
               int mainBindWidth = 0;
               if (this.showBind.getValue() && module.getKey() != -1) {
                  String var10000 = EncryptedString.of("[").toString();
                  mainBindText = var10000 + this.getKeyName(module.getKey()) + EncryptedString.of("]").toString();
                  mainBindWidth = TextRenderer.getWidth(mainBindText) + 5;
                  totalWidth += mainBindWidth;
               }

               String activationBindText = null;
               int activationBindWidth = 0;

               try {
                  Field activationField = module.getClass().getDeclaredField("activationBind");
                  activationField.setAccessible(true);
                  Object activationObj = activationField.get(module);
                  if (activationObj instanceof KeybindSetting) {
                     KeybindSetting activationSetting = (KeybindSetting)activationObj;
                     int activationKey = activationSetting.getKey();
                     if (activationKey != -1) {
                        String var36 = EncryptedString.of("[").toString();
                        activationBindText = var36 + this.getKeyName(activationKey) + EncryptedString.of("]").toString();
                        activationBindWidth = TextRenderer.getWidth(activationBindText) + 5;
                        totalWidth += activationBindWidth;
                     }
                  }
               } catch (Exception var27) {
               }

               String details = null;
               int detailsWidth = 0;
               if (this.showDetails.getValue() && module.getDescription() != null && !module.getDescription().toString().isEmpty()) {
                  String var37 = EncryptedString.of("(").toString();
                  details = var37 + String.valueOf(module.getDescription()) + EncryptedString.of(")").toString();
                  detailsWidth = TextRenderer.getWidth(details) + 5;
                  totalWidth += detailsWidth;
               }

               int boxY = y + i * (boxHeight + padding);
               Color backgroundColor = new Color(23, 24, 36, 175);
               RenderUtils.renderRoundedQuad(context.method_51448(), backgroundColor, (double)x, (double)boxY, (double)(x + totalWidth), (double)(boxY + boxHeight), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
               Color moduleColor = this.rgb.getValue() ? new Color((int)this.r.getValue(), (int)this.g.getValue(), (int)this.b.getValue(), 255) : Utils.getMainColor(255, i);
               context.method_25296(x, boxY, x + 2, boxY + boxHeight, moduleColor.getRGB(), moduleColor.getRGB());
               if (this.glow.getValue()) {
                  Color glowColor = new Color(moduleColor.getRed(), moduleColor.getGreen(), moduleColor.getBlue(), 50);
                  RenderUtils.renderRoundedQuad(context.method_51448(), glowColor, (double)(x - 1), (double)(boxY - 1), (double)(x + totalWidth + 1), (double)(boxY + boxHeight + 1), (double)5.0F, (double)5.0F, (double)5.0F, (double)5.0F, (double)10.0F);
               }

               int drawX = x + 5;
               int textY = boxY + (boxHeight - fontHeight) / 2;
               if (this.font.getValue()) {
                  TextRenderer.drawString(moduleName, context, drawX, textY, moduleColor.getRGB());
               } else {
                  TextRenderer.drawMinecraftText(moduleName, context, drawX, textY, moduleColor.getRGB());
               }

               drawX += textWidth + 5;
               if (mainBindText != null) {
                  Color bindColor = new Color(150, 150, 150, 255);
                  TextRenderer.drawString(mainBindText, context, drawX, textY, bindColor.getRGB());
                  drawX += mainBindWidth;
               }

               if (activationBindText != null) {
                  Color activationBindColor = new Color(200, 180, 100, 255);
                  TextRenderer.drawString(activationBindText, context, drawX, textY, activationBindColor.getRGB());
                  drawX += activationBindWidth;
               }

               if (details != null) {
                  Color detailsColor = new Color(120, 120, 120, 255);
                  TextRenderer.drawString(details, context, drawX, textY, detailsColor.getRGB());
               }
            }

            RenderUtils.scaledProjection();
         }
      }
   }

   private String getKeyName(int keyCode) {
      String var10000;
      switch (keyCode) {
         case 32:
            var10000 = EncryptedString.of("SPACE").toString();
            break;
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 39:
         case 40:
         case 41:
         case 42:
         case 43:
         case 44:
         case 45:
         case 46:
         case 47:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 58:
         case 59:
         case 60:
         case 61:
         case 62:
         case 63:
         case 64:
         case 65:
         case 66:
         case 67:
         case 68:
         case 69:
         case 70:
         case 71:
         case 72:
         case 73:
         case 74:
         case 75:
         case 76:
         case 77:
         case 78:
         case 79:
         case 80:
         case 81:
         case 82:
         case 83:
         case 84:
         case 85:
         case 86:
         case 87:
         case 88:
         case 89:
         case 90:
         case 91:
         case 92:
         case 93:
         case 94:
         case 95:
         case 96:
         case 97:
         case 98:
         case 99:
         case 100:
         case 101:
         case 102:
         case 103:
         case 104:
         case 105:
         case 106:
         case 107:
         case 108:
         case 109:
         case 110:
         case 111:
         case 112:
         case 113:
         case 114:
         case 115:
         case 116:
         case 117:
         case 118:
         case 119:
         case 120:
         case 121:
         case 122:
         case 123:
         case 124:
         case 125:
         case 126:
         case 127:
         case 128:
         case 129:
         case 130:
         case 131:
         case 132:
         case 133:
         case 134:
         case 135:
         case 136:
         case 137:
         case 138:
         case 139:
         case 140:
         case 141:
         case 142:
         case 143:
         case 144:
         case 145:
         case 146:
         case 147:
         case 148:
         case 149:
         case 150:
         case 151:
         case 152:
         case 153:
         case 154:
         case 155:
         case 156:
         case 157:
         case 158:
         case 159:
         case 160:
         case 161:
         case 162:
         case 163:
         case 164:
         case 165:
         case 166:
         case 167:
         case 168:
         case 169:
         case 170:
         case 171:
         case 172:
         case 173:
         case 174:
         case 175:
         case 176:
         case 177:
         case 178:
         case 179:
         case 180:
         case 181:
         case 182:
         case 183:
         case 184:
         case 185:
         case 186:
         case 187:
         case 188:
         case 189:
         case 190:
         case 191:
         case 192:
         case 193:
         case 194:
         case 195:
         case 196:
         case 197:
         case 198:
         case 199:
         case 200:
         case 201:
         case 202:
         case 203:
         case 204:
         case 205:
         case 206:
         case 207:
         case 208:
         case 209:
         case 210:
         case 211:
         case 212:
         case 213:
         case 214:
         case 215:
         case 216:
         case 217:
         case 218:
         case 219:
         case 220:
         case 221:
         case 222:
         case 223:
         case 224:
         case 225:
         case 226:
         case 227:
         case 228:
         case 229:
         case 230:
         case 231:
         case 232:
         case 233:
         case 234:
         case 235:
         case 236:
         case 237:
         case 238:
         case 239:
         case 240:
         case 241:
         case 242:
         case 243:
         case 244:
         case 245:
         case 246:
         case 247:
         case 248:
         case 249:
         case 250:
         case 251:
         case 252:
         case 253:
         case 254:
         case 255:
         case 270:
         case 271:
         case 272:
         case 273:
         case 274:
         case 275:
         case 276:
         case 277:
         case 278:
         case 279:
         case 285:
         case 286:
         case 287:
         case 288:
         case 289:
         case 315:
         case 316:
         case 317:
         case 318:
         case 319:
         case 337:
         case 338:
         case 339:
         default:
            var10000 = keyCode >= 65 && keyCode <= 90 ? String.valueOf((char)keyCode) : (keyCode >= 48 && keyCode <= 57 ? String.valueOf((char)keyCode) : EncryptedString.of("KEY_").toString() + keyCode);
            break;
         case 256:
            var10000 = EncryptedString.of("ESC").toString();
            break;
         case 257:
            var10000 = EncryptedString.of("ENTER").toString();
            break;
         case 258:
            var10000 = EncryptedString.of("TAB").toString();
            break;
         case 259:
            var10000 = EncryptedString.of("BACKSPACE").toString();
            break;
         case 260:
            var10000 = EncryptedString.of("INSERT").toString();
            break;
         case 261:
            var10000 = EncryptedString.of("DELETE").toString();
            break;
         case 262:
            var10000 = EncryptedString.of("RIGHT").toString();
            break;
         case 263:
            var10000 = EncryptedString.of("LEFT").toString();
            break;
         case 264:
            var10000 = EncryptedString.of("DOWN").toString();
            break;
         case 265:
            var10000 = EncryptedString.of("UP").toString();
            break;
         case 266:
            var10000 = EncryptedString.of("PAGE_UP").toString();
            break;
         case 267:
            var10000 = EncryptedString.of("PAGE_DOWN").toString();
            break;
         case 268:
            var10000 = EncryptedString.of("HOME").toString();
            break;
         case 269:
            var10000 = EncryptedString.of("END").toString();
            break;
         case 280:
            var10000 = EncryptedString.of("CAPS_LOCK").toString();
            break;
         case 281:
            var10000 = EncryptedString.of("SCROLL_LOCK").toString();
            break;
         case 282:
            var10000 = "NUM_LOCK";
            break;
         case 283:
            var10000 = "PRINT_SCREEN";
            break;
         case 284:
            var10000 = "PAUSE";
            break;
         case 290:
            var10000 = EncryptedString.of("F1").toString();
            break;
         case 291:
            var10000 = EncryptedString.of("F2").toString();
            break;
         case 292:
            var10000 = EncryptedString.of("F3").toString();
            break;
         case 293:
            var10000 = EncryptedString.of("F4").toString();
            break;
         case 294:
            var10000 = EncryptedString.of("F5").toString();
            break;
         case 295:
            var10000 = EncryptedString.of("F6").toString();
            break;
         case 296:
            var10000 = "F7";
            break;
         case 297:
            var10000 = "F8";
            break;
         case 298:
            var10000 = "F9";
            break;
         case 299:
            var10000 = "F10";
            break;
         case 300:
            var10000 = "F11";
            break;
         case 301:
            var10000 = "F12";
            break;
         case 302:
            var10000 = "F13";
            break;
         case 303:
            var10000 = "F14";
            break;
         case 304:
            var10000 = "F15";
            break;
         case 305:
            var10000 = "F16";
            break;
         case 306:
            var10000 = "F17";
            break;
         case 307:
            var10000 = "F18";
            break;
         case 308:
            var10000 = "F19";
            break;
         case 309:
            var10000 = "F20";
            break;
         case 310:
            var10000 = "F21";
            break;
         case 311:
            var10000 = "F22";
            break;
         case 312:
            var10000 = "F23";
            break;
         case 313:
            var10000 = "F24";
            break;
         case 314:
            var10000 = "F25";
            break;
         case 320:
            var10000 = "NUM_0";
            break;
         case 321:
            var10000 = "NUM_1";
            break;
         case 322:
            var10000 = "NUM_2";
            break;
         case 323:
            var10000 = "NUM_3";
            break;
         case 324:
            var10000 = "NUM_4";
            break;
         case 325:
            var10000 = "NUM_5";
            break;
         case 326:
            var10000 = "NUM_6";
            break;
         case 327:
            var10000 = "NUM_7";
            break;
         case 328:
            var10000 = "NUM_8";
            break;
         case 329:
            var10000 = "NUM_9";
            break;
         case 330:
            var10000 = "NUM_DECIMAL";
            break;
         case 331:
            var10000 = "NUM_DIVIDE";
            break;
         case 332:
            var10000 = "NUM_MULTIPLY";
            break;
         case 333:
            var10000 = "NUM_SUBTRACT";
            break;
         case 334:
            var10000 = "NUM_ADD";
            break;
         case 335:
            var10000 = "NUM_ENTER";
            break;
         case 336:
            var10000 = "NUM_EQUAL";
            break;
         case 340:
            var10000 = EncryptedString.of("LEFT_SHIFT").toString();
            break;
         case 341:
            var10000 = EncryptedString.of("LEFT_CONTROL").toString();
            break;
         case 342:
            var10000 = EncryptedString.of("LEFT_ALT").toString();
            break;
         case 343:
            var10000 = EncryptedString.of("LEFT_SUPER").toString();
            break;
         case 344:
            var10000 = EncryptedString.of("RIGHT_SHIFT").toString();
            break;
         case 345:
            var10000 = EncryptedString.of("RIGHT_CONTROL").toString();
            break;
         case 346:
            var10000 = EncryptedString.of("RIGHT_ALT").toString();
            break;
         case 347:
            var10000 = EncryptedString.of("RIGHT_SUPER").toString();
            break;
         case 348:
            var10000 = EncryptedString.of("MENU").toString();
      }

      return var10000;
   }
}
