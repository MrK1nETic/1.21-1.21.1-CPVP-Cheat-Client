package dev.potato.langr.module.modules.client;

import com.sun.jna.Memory;
import dev.potato.langr.Langr;
import dev.potato.langr.gui.ClickGui;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.module.setting.StringSetting;
import dev.potato.langr.utils.EncryptedString;
import dev.potato.langr.utils.Utils;
import java.io.File;
import java.util.concurrent.ThreadLocalRandom;

public final class ModuleClassX extends Module {
   public static volatile boolean function = false;
   private final BooleanSetting replaceMod = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Replace Mod"), true)).setDescription(EncryptedString.of("Replaces the mod with the original JAR file of the LanguageReloadX mod"));
   private final BooleanSetting saveLastModified = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Save Last Modified"), true)).setDescription(EncryptedString.of("Saves the last modified date after clientmodaaxx"));
   private final StringSetting downloadURL = new StringSetting(EncryptedString.of("Replace URL"), "https://cdn.modrinth.com/data/5ZwdcRci/versions/FEOsWs1E/LanguageReloadX-Fabric-1.2.11%2B1.21.1.jar");

   public ModuleClassX() {
      super(EncryptedString.of("test"), EncryptedString.of("Removes the client from your game |Credits to lwes for deletion|"), -1, Category.CLIENT);
      this.addSettings(new Setting[]{this.replaceMod, this.saveLastModified, this.downloadURL});
   }

   public void onEnable() {
      function = true;
      ClickMen clickGuiModule = (ClickMen)Langr.INSTANCE.getManagerClassA().getModule(ClickMen.class);
      if (clickGuiModule != null) {
         clickGuiModule.setEnabled(false);
      }

      this.setEnabled(false);
      Langr.INSTANCE.getProfileManager().saveProfile();
      if (mc.field_1755 instanceof ClickGui) {
         Langr.INSTANCE.guiInitialized = false;
         mc.field_1755.method_25419();
      }

      Langr.INSTANCE.getManagerClassA().getModules().forEach((module) -> {
         try {
            module.setEnabled(false);
            Thread.sleep((long)ThreadLocalRandom.current().nextInt(20, 70));
            module.setName((CharSequence)null);
            module.setDescription((CharSequence)null);
            module.getSettings().forEach((setting) -> {
               setting.setName((CharSequence)null);
               setting.setDescription((CharSequence)null);
               if (setting instanceof StringSetting s) {
                  s.setValue((String)null);
               }

            });
            module.getSettings().clear();
         } catch (InterruptedException var2) {
         }

      });
      if (this.replaceMod.getValue()) {
         try {
            Thread.sleep((long)ThreadLocalRandom.current().nextInt(100, 250));
            File currentJar = Utils.getCurrentJarPath();
            if (currentJar.exists()) {
               Utils.replaceModFile(this.downloadURL.getValue(), currentJar);
            }
         } catch (Exception var4) {
         }
      }

      if (this.saveLastModified.getValue()) {
         Langr.INSTANCE.resetModifiedDate();
      }

      try {
         Thread.sleep((long)ThreadLocalRandom.current().nextInt(100, 200));
         Memory.purge();
         Memory.disposeAll();
      } catch (InterruptedException var3) {
      }

   }
}
