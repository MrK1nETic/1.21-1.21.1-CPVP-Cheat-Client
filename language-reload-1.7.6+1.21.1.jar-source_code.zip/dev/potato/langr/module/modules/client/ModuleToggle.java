package dev.potato.langr.module.modules.client;

import dev.potato.langr.Langr;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.ModeSetting;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.EncryptedString;
import java.util.List;

public class ModuleToggle extends Module {
   private final ModeSetting<ToggleMode> toggleMode;
   private final BooleanSetting saveState;
   private final BooleanSetting autoDisable;
   private final NumberSetting delay;
   private final BooleanSetting excludeGui;
   private final BooleanSetting excludeThis;
   private List<Module> previousState;

   public ModuleToggle() {
      super(EncryptedString.of("Module Toggle"), EncryptedString.of("Quickly toggle all modules on/off"), -1, Category.CLIENT);
      this.toggleMode = (ModeSetting)(new ModeSetting(EncryptedString.of("Toggle Mode"), ModuleToggle.ToggleMode.OFF_ALL, ToggleMode.class)).setDescription(EncryptedString.of("What action to perform when this module is activated"));
      this.saveState = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Save State"), true)).setDescription(EncryptedString.of("Save the current state of modules before toggling"));
      this.autoDisable = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Auto Disable"), true)).setDescription(EncryptedString.of("Automatically disable this module after performing action"));
      this.delay = (NumberSetting)(new NumberSetting(EncryptedString.of("Delay (ms)"), (double)0.0F, (double)2000.0F, (double)500.0F, (double)50.0F)).setDescription(EncryptedString.of("Delay before auto-disabling this module"));
      this.excludeGui = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Exclude GUI"), true)).setDescription(EncryptedString.of("Don't toggle ClickMen module"));
      this.excludeThis = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Exclude This Module"), true)).setDescription(EncryptedString.of("Don't toggle this module ittest"));
      this.previousState = new java.util.ArrayList();
      this.addSettings(new Setting[]{this.toggleMode, this.saveState, this.autoDisable, this.delay, this.excludeGui, this.excludeThis});
   }

   public void onEnable() {
      switch (((ToggleMode)this.toggleMode.getMode()).ordinal()) {
         case 0 -> this.turnOffAllModules();
         case 1 -> this.turnOnAllModules();
         case 2 -> this.toggleAllModules();
         case 3 -> this.restorePreviousState();
      }

      if (this.autoDisable.getValue()) {
         (new Thread(() -> {
            try {
               Thread.sleep((long)this.delay.getValue());
               if (this.isEnabled()) {
                  this.setEnabled(false);
               }
            } catch (InterruptedException var2) {
            }

         })).start();
      }

   }

   private void turnOffAllModules() {
      if (this.saveState.getValue()) {
         this.saveCurrentState();
      }

      for(Module module : Langr.INSTANCE.getManagerClassA().getModules()) {
         if (!this.shouldExcludeModule(module) && module.isEnabled()) {
            module.setEnabled(false);
         }
      }

      Langr.INSTANCE.getProfileManager().saveProfile();
   }

   private void turnOnAllModules() {
      if (this.saveState.getValue()) {
         this.saveCurrentState();
      }

      for(Module module : Langr.INSTANCE.getManagerClassA().getModules()) {
         if (!this.shouldExcludeModule(module) && !module.isEnabled()) {
            module.setEnabled(true);
         }
      }

      Langr.INSTANCE.getProfileManager().saveProfile();
   }

   private void toggleAllModules() {
      if (this.saveState.getValue()) {
         this.saveCurrentState();
      }

      for(Module module : Langr.INSTANCE.getManagerClassA().getModules()) {
         if (!this.shouldExcludeModule(module)) {
            module.setEnabled(!module.isEnabled());
         }
      }

      Langr.INSTANCE.getProfileManager().saveProfile();
   }

   private void restorePreviousState() {
      if (this.previousState.isEmpty()) {
         this.turnOffAllModules();
      } else {
         for(Module module : Langr.INSTANCE.getManagerClassA().getModules()) {
            if (!this.shouldExcludeModule(module)) {
               boolean wasEnabled = this.previousState.contains(module);
               if (module.isEnabled() != wasEnabled) {
                  module.setEnabled(wasEnabled);
               }
            }
         }

         Langr.INSTANCE.getProfileManager().saveProfile();
      }
   }

   private void saveCurrentState() {
      this.previousState.clear();

      for(Module module : Langr.INSTANCE.getManagerClassA().getModules()) {
         if (!this.shouldExcludeModule(module) && module.isEnabled()) {
            this.previousState.add(module);
         }
      }

   }

   private boolean shouldExcludeModule(Module module) {
      if (this.excludeThis.getValue() && module == this) {
         return true;
      } else if (this.excludeGui.getValue() && module instanceof ClickMen) {
         return true;
      } else {
         return module instanceof ModuleClassX;
      }
   }

   public void onDisable() {
   }

   public static enum ToggleMode {
      OFF_ALL("Turn Off All"),
      ON_ALL("Turn On All"),
      TOGGLE_ALL("Toggle All"),
      RESTORE_STATE("Restore Previous State");

      private final String displayName;

      private ToggleMode(String displayName) {
         this.displayName = displayName;
      }

      public String toString() {
         return this.displayName;
      }

      // $FF: synthetic method
      private static ToggleMode[] $values() {
         return new ToggleMode[]{OFF_ALL, ON_ALL, TOGGLE_ALL, RESTORE_STATE};
      }
   }
}
