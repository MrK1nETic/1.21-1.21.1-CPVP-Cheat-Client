package dev.potato.langr.module.modules.client;

import dev.potato.langr.Langr;
import dev.potato.langr.event.events.PacketReceiveListener;
import dev.potato.langr.gui.ClickGui;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.module.setting.BooleanSetting;
import dev.potato.langr.module.setting.KeybindSetting;
import dev.potato.langr.module.setting.ModeSetting;
import dev.potato.langr.module.setting.NumberSetting;
import dev.potato.langr.module.setting.Setting;
import dev.potato.langr.utils.EncryptedString;
import net.minecraft.class_3944;

public final class ClickMen extends Module implements PacketReceiveListener {
   public static final BooleanSetting breathing = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Breathing"), true)).setDescription(EncryptedString.of("Color breathing effect (only with rainbow off)"));
   public static final BooleanSetting rainbow = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Rainbow"), true)).setDescription(EncryptedString.of("Enables LGBTQ mode"));
   public static final NumberSetting rainbowSpeed = (NumberSetting)(new NumberSetting(EncryptedString.of("Rainbow Speed"), 0.1, (double)5.0F, (double)1.0F, 0.1)).setDescription(EncryptedString.of("Speed of rainbow color cycling"));
   public static final BooleanSetting background = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Background"), false)).setDescription(EncryptedString.of("Renders the background of the Click Gui"));
   public static final NumberSetting backgroundAlpha = (NumberSetting)(new NumberSetting(EncryptedString.of("Background Alpha"), (double)0.0F, (double)255.0F, (double)200.0F, (double)5.0F)).setDescription(EncryptedString.of("Transparency of background overlay"));
   public static final BooleanSetting antiAliasing = (BooleanSetting)(new BooleanSetting(EncryptedString.of("MSAA"), true)).setDescription(EncryptedString.of("Anti Aliasing | This can impact performance if you're using tracers but gives them a smoother look |"));
   private final BooleanSetting preventClose = (BooleanSetting)(new BooleanSetting(EncryptedString.of("ModDelA Close"), true)).setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final BooleanSetting customFont = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Custom Font"), true)).setDescription(EncryptedString.of("Use custom font instead of vanilla"));
   public static final NumberSetting red = new NumberSetting(EncryptedString.of("Red"), (double)0.0F, (double)255.0F, (double)255.0F, (double)1.0F);
   public static final NumberSetting green = new NumberSetting(EncryptedString.of("Green"), (double)0.0F, (double)255.0F, (double)0.0F, (double)1.0F);
   public static final NumberSetting blue = new NumberSetting(EncryptedString.of("Blue"), (double)0.0F, (double)255.0F, (double)50.0F, (double)1.0F);
   public static final NumberSetting alphaWindow = new NumberSetting(EncryptedString.of("Window Alpha"), (double)0.0F, (double)255.0F, (double)170.0F, (double)1.0F);
   public static final NumberSetting roundQuads = new NumberSetting(EncryptedString.of("Roundness"), (double)1.0F, (double)10.0F, (double)5.0F, (double)1.0F);
   public static final ModeSetting<AnimationMode> animationMode;
   public static final KeybindSetting friendsWindowKey;

   public ClickMen() {
      super(EncryptedString.of("Langr+"), EncryptedString.of("Settings for the client"), 297, Category.CLIENT);
      this.addSettings(new Setting[]{red, green, blue, alphaWindow, breathing, rainbow, background, this.preventClose, roundQuads, animationMode, antiAliasing, backgroundAlpha, customFont, friendsWindowKey});
   }

   public void onEnable() {
      this.eventManager.add(PacketReceiveListener.class, this);
      Langr.INSTANCE.previousScreen = mc.field_1755;
      mc.method_1507(new ClickGui());
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(PacketReceiveListener.class, this);
      if (mc.field_1755 instanceof ClickGui) {
         mc.field_1755.method_25419();
      }

      super.onDisable();
   }

   public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
      if (this.preventClose.getValue() && event.packet instanceof class_3944) {
         event.cancel();
      }

   }

   static {
      animationMode = new ModeSetting<AnimationMode>(EncryptedString.of("Animations"), ClickMen.AnimationMode.Normal, AnimationMode.class);
      friendsWindowKey = (KeybindSetting)(new KeybindSetting(EncryptedString.of("Friends Window Key"), 345, false)).setDescription(EncryptedString.of("Key to open the Friends window only"));
   }

   public static enum AnimationMode {
      Normal,
      Positive,
      Off;

      // $FF: synthetic method
      private static AnimationMode[] $values() {
         return new AnimationMode[]{Normal, Positive, Off};
      }
   }
}
