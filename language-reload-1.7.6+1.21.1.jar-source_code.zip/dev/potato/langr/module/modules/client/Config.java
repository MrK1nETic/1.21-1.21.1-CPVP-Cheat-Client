package dev.potato.langr.module.modules.client;

import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;

public class Config extends Module {
   public static String[] dO = new String[5];
   public static String[] dN = new String[]{"\u0001D", "\u001d\u0094n£4ÎÎýL", "7ôl²I~Ñ&D", "8}BK\u0082¤", "8+\u0083OÍj \u0006e"};

   public Config() {
      super("Config", "Config module description", -1, Category.CLIENT);
   }
}
