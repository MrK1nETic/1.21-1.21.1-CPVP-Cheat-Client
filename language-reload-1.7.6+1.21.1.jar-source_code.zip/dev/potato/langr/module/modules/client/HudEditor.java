package dev.potato.langr.module.modules.client;

import dev.potato.langr.gui.HudEditorGui;
import dev.potato.langr.module.Category;
import dev.potato.langr.module.Module;
import dev.potato.langr.utils.EncryptedString;
import net.minecraft.class_310;

public class HudEditor extends Module {
   public HudEditor() {
      super(EncryptedString.of("Hud Editor"), EncryptedString.of("Opens the HUD editor."), -1, Category.CLIENT);
   }

   public void onEnable() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1755 != null) {
         mc.method_1507(new HudEditorGui(mc.field_1755));
      }

      this.setEnabled(false);
   }
}
