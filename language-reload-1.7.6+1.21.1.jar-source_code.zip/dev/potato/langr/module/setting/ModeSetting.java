package dev.potato.langr.module.setting;

import java.util.Arrays;
import java.util.List;

public final class ModeSetting<T extends Enum<T>> extends Setting<ModeSetting<T>> {
   private final List<T> possibleValues;
   private final int originalValue;
   public int index;

   public ModeSetting(CharSequence name, T defaultValue, Class<T> type) {
      super(name);
      T[] values = (T[])(type.getEnumConstants());
      this.possibleValues = Arrays.asList(values);
      this.index = this.possibleValues.indexOf(defaultValue);
      this.originalValue = this.index;
   }

   public T getMode() {
      return (T)(this.possibleValues.get(this.index));
   }

   public void setMode(T mode) {
      this.index = this.possibleValues.indexOf(mode);
   }

   public int getModeIndex() {
      return this.index;
   }

   public void setModeIndex(int mode) {
      this.index = mode;
   }

   public int getOriginalValue() {
      return this.originalValue;
   }

   public void cycle() {
      if (this.index < this.possibleValues.size() - 1) {
         ++this.index;
      } else {
         this.index = 0;
      }

   }

   public void cycleBackward() {
      if (this.index > 0) {
         --this.index;
      } else {
         this.index = this.possibleValues.size() - 1;
      }

   }

   public List<T> getModes() {
      return this.possibleValues;
   }

   public T getDefaultValue() {
      return (T)(this.possibleValues.get(this.originalValue));
   }

   public boolean isMode(T mode) {
      return this.index == this.possibleValues.indexOf(mode);
   }

   public String getDisplayValue() {
      return this.getMode().toString();
   }

   public T getValueFromString(String name) {
      for(T value : this.possibleValues) {
         if (value.toString().equalsIgnoreCase(name) || value.name().equalsIgnoreCase(name)) {
            return value;
         }
      }

      return null;
   }
}
