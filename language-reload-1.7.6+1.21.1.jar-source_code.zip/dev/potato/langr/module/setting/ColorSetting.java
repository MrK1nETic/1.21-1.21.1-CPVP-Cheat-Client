package dev.potato.langr.module.setting;

import java.awt.Color;

public class ColorSetting extends Setting {
   private Color color;

   public ColorSetting(CharSequence name, Color defaultColor) {
      super(name);
      this.color = defaultColor;
   }

   public Color getColor() {
      return this.color;
   }

   public void setColor(Color color) {
      this.color = color;
   }

   public Color getValue() {
      return this.color;
   }

   public String getDisplayValue() {
      return String.format("#%02X%02X%02X%02X", this.color.getRed(), this.color.getGreen(), this.color.getBlue(), this.color.getAlpha());
   }
}
