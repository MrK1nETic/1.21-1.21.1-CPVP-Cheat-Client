package dev.potato.langr.module.setting;

import net.minecraft.class_1792;

public class ItemSetting extends Setting {
   private final class_1792 defaultValue;
   private class_1792 value;
   private boolean listening = false;

   public ItemSetting(CharSequence name, class_1792 value) {
      super(name);
      this.value = value;
      this.defaultValue = value;
   }

   public class_1792 getItem() {
      return this.value;
   }

   public void setItem(class_1792 a) {
      this.value = a;
   }

   public class_1792 getValue() {
      return this.value;
   }

   public void setValue(class_1792 value) {
      this.value = value;
   }

   public void toggleListening() {
      this.listening = !this.listening;
   }

   public boolean isListening() {
      return this.listening;
   }

   public class_1792 getDefaultValue() {
      return this.defaultValue;
   }

   public void resetValue() {
      this.value = this.defaultValue;
   }

   public String getDisplayValue() {
      return this.value.toString();
   }
}
