package dev.potato.langr.module.setting;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1792;

public class MultiItemSetting extends Setting<MultiItemSetting> {
   private final Set<class_1792> defaultItems;
   private final Set<class_1792> selectedItems;
   private boolean listening = false;

   public MultiItemSetting(CharSequence name, Set<class_1792> defaultItems) {
      super(name);
      this.defaultItems = new HashSet(defaultItems);
      this.selectedItems = new HashSet(defaultItems);
   }

   public Set<class_1792> getItems() {
      return this.selectedItems;
   }

   public void setItems(Set<class_1792> items) {
      this.selectedItems.clear();
      this.selectedItems.addAll(items);
   }

   public void addItem(class_1792 item) {
      this.selectedItems.add(item);
   }

   public void removeItem(class_1792 item) {
      this.selectedItems.remove(item);
   }

   public void toggleListening() {
      this.listening = !this.listening;
   }

   public boolean isListening() {
      return this.listening;
   }

   public Set<class_1792> getDefaultItems() {
      return this.defaultItems;
   }

   public void resetValue() {
      this.selectedItems.clear();
      this.selectedItems.addAll(this.defaultItems);
   }

   public String getDisplayValue() {
      return this.selectedItems.isEmpty() ? "None" : (String)this.selectedItems.stream().map(Object::toString).collect(Collectors.joining(", "));
   }

   public class_1792 getItem() {
      return (class_1792)this.selectedItems.stream().findFirst().orElse((Object)null);
   }
}
