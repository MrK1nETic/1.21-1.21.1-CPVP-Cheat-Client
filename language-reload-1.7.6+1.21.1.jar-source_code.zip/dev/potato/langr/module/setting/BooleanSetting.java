package dev.potato.langr.module.setting;

public final class BooleanSetting extends Setting<BooleanSetting> {
   private boolean enabled;
   private final boolean originalValue;

   public BooleanSetting(CharSequence name, boolean defaultValue) {
      super(name);
      this.enabled = defaultValue;
      this.originalValue = defaultValue;
   }

   public boolean getValue() {
      return this.enabled;
   }

   public void setValue(boolean value) {
      this.enabled = value;
   }

   public void toggle() {
      this.enabled = !this.enabled;
   }

   public boolean getOriginalValue() {
      return this.originalValue;
   }

   public String getDisplayValue() {
      return this.enabled ? "Enabled" : "Disabled";
   }
}
