package dev.potato.langr.module.setting;

public abstract class Setting<T extends Setting<T>> {
   public CharSequence description;
   private CharSequence name;

   public Setting(CharSequence name) {
      this.name = name;
   }

   public CharSequence getName() {
      return this.name;
   }

   public void setName(CharSequence name) {
      this.name = name;
   }

   public CharSequence getDescription() {
      return this.description;
   }

   public T setDescription(CharSequence desc) {
      this.description = desc;
      return (T)this;
   }

   public abstract String getDisplayValue();
}
