package dev.potato.langr.module;

import dev.potato.langr.Langr;
import dev.potato.langr.event.events.ButtonListener;
import dev.potato.langr.module.modules.client.ClickMen;
import dev.potato.langr.module.modules.client.Config;
import dev.potato.langr.module.modules.client.HudEditor;
import dev.potato.langr.module.modules.client.ModuleClassX;
import dev.potato.langr.module.modules.client.ModuleToggle;
import dev.potato.langr.module.modules.cpvp.AnchorItemA;
import dev.potato.langr.module.modules.cpvp.CrystalModAA;
import dev.potato.langr.module.modules.cpvp.TotemInventoryModX;
import dev.potato.langr.module.modules.sword.BlockDefModAAA;
import dev.potato.langr.module.setting.KeybindSetting;
import dev.potato.langr.utils.EncryptedString;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public final class ManagerClassA implements ButtonListener {
   private final List<Module> modules = new ArrayList();

   public ManagerClassA() {
      this.addModules();
      this.addKeybinds();
   }

   public void addModules() {
      this.add(new CrystalModAA());
      this.add(new BlockDefModAAA());
      this.add(new AnchorItemA());
      this.add(new TotemInventoryModX());
      this.add(new dev.potato.langr.module.modules.client.ArrayList());
      this.add(new ClickMen());
      this.add(new Config());
      this.add(new HudEditor());
      this.add(new ModuleToggle());
      this.add(new ModuleClassX());
   }

   public List<Module> getEnabledModules() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> getModules() {
      return this.modules;
   }

   public void addKeybinds() {
      Langr.INSTANCE.getEventManager().add(ButtonListener.class, this);

      for(Module module : this.modules) {
         module.addSetting((new KeybindSetting(EncryptedString.of("Keybind"), module.getKey(), true)).setDescription(EncryptedString.of("Key to enabled the module")));
      }

   }

   public List<Module> getModulesInCategory(Category category) {
      return this.modules.stream().filter((module) -> module.getCategory() == category).toList();
   }

   public <T extends Module> T getModule(Class<T> moduleClass) {
      Stream var10000 = this.modules.stream();
      Objects.requireNonNull(moduleClass);
      return (T)(var10000.filter(moduleClass::isInstance).findFirst().orElse((Object)null));
   }

   public void add(Module module) {
      this.modules.add(module);
   }

   public void onButtonPress(ButtonListener.ButtonEvent event) {
      if (!ModuleClassX.function) {
         if (ClickMen.friendsWindowKey.getKey() == event.button && event.action == 1) {
            Langr.INSTANCE.openFriendsWindowOnly();
            return;
         }

         this.modules.forEach((module) -> {
            if (module.getKey() == event.button && event.action == 1) {
               module.toggle();
            }

         });
      }

   }
}
