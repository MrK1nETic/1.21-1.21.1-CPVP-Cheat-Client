package dev.potato.langr.module;

import dev.potato.langr.utils.EncryptedString;

public enum Category {
   CPVP(EncryptedString.of("Cpvp")),
   SWORD(EncryptedString.of("Sword")),
   MOVEMENT(EncryptedString.of("Movement")),
   MISC(EncryptedString.of("Misc")),
   PLAYER(EncryptedString.of("Player")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(CharSequence name) {
      this.name = name;
   }

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{CPVP, SWORD, MOVEMENT, MISC, PLAYER, RENDER, CLIENT};
   }
}
